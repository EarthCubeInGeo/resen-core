#Copyright 2018, The Regents of the University of Colorado, a body corporate
# Created by the CU Boulder AMGeO Collaboration
import os
import glob

os.environ['DISTUTILS_DEBUG'] = "1"

from setuptools import setup, Extension
from setuptools.command import install as _install

setup(name='AMGeO',
      version = "2.0.0",
      description = "The Assimilative Mapping of Geospace Observations (AMGeO)",
      author = "CU Boulder AMGeO Collaboration",
      author_email = 'amgeo@colorado.edu',
      url = "https://amgeo.colorado.edu",
      download_url = "https://github.com/AMGeO-Collaboration/AMGeO",
      long_description = """
                        This is the Assimilative Mapping of Geospace Observations
            (AMGeO), a data assmilation package which extends
            the methods used in the Assimilative Mapping of
            Ionospheric Electrodynamics. AMGeO is implemented as a
            community data assimilation toolkit using community
            data resouces.
            """,
      install_requires=['numpy','matplotlib','scipy','scikit-learn','apexpy',
                        'pytest','h5py','requests','netcdf4','logbook'],
      packages=['AMGeO'],
      package_dir={'AMGeO' : 'AMGeO'},
      package_data={
                  'AMGeO': [
                              'config/amgeo_user.json',
                              'tables/covariance/*',
                              'tables/test_amgeo_basis/*',
                              'tables/test_amgeo_obs/*',
                              'tables/test_amgeo_core/*',
                              'tables/amieqset/*',
                              'tables/amieqsetz/*',
                              'tables/cs10/*'
                        ]
                  },
      license='LICENSE.txt',
      zip_safe = False,
      classifiers = [
            "Development Status :: 4 - Beta",
            "Topic :: Scientific/Engineering",
            "Intended Audience :: Science/Research",
            "Natural Language :: English",
            "Programming Language :: Python"
            ],
      )
