.. AMGeO documentation master file, created by
   sphinx-quickstart on Mon Jul 24 13:46:37 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to AMGeO's documentation!
======================================= 

`AMGeO Webpage <https://amgeo.colorado.edu>`_

`AMGeO Whitepaper <https://doi.org/10.5281/zenodo.3564913>`_

`AMGeO on Github <https://github.com/AMGeO-Collaboration>`_

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   quickstart
   overview
   api

