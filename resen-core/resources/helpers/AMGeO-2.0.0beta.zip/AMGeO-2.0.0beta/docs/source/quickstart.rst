Quickstart
==========


Registration
------------

To use AMGeO you will need to register at https://amgeo.colorado.edu. An AMGeO
Collaboration member will have to approve your registration before you will
be able to log in which may take up to one buisness day.

Github
------

The AMGeO source code is distributed through a Github organization. After your
registration has been approved, you will be able to link your Github account
to our organization and access our repository. To do this:

#. Log in at https://amgeo.colorado.edu/login
#. Go to the account page https://amgeo.colorado.edu/account
#. Enter your Github username

An invitation to the AMGeO Community will be sent to the email address 
associated with your Github account.

API Key
-------

Your API key links your local installation to your account on our website, and allows you
to download data through our web service.

.. note::
	The AMGeO data service keeps a log of which API keys are requesting data and how often.
	We will report statistics based on this information to funding agencies 
	(e.g. National Science Foundation). Such reports will never contain
	personally identifiable information (e.g. usernames, email addresses) of AMGeO users.
	See the AMGeO license and privacy policy for further information.

After you have registered, get your API key by:

#. Log in at https://amgeo.colorado.edu/login
#. Go to the account page https://amgeo.colorado.edu/account or click your username in the top right corner of the page
#. Click the API key button

Installation
------------

1. Make sure numpy is installed

.. code::

	pip install numpy

2. Clone the AMGeO Github repository

.. code::

	git clone https://github.com/amgeo-collaboration/AMGeO.git

3. Install the latest versions of the AMGeO dependancies

.. code::

	cd AMGeO
	pip install -r requirements.txt

4. Install AMGeO itself in develop mode

.. code::

	python setup.py develop

Configure
---------
	
Ensure you have your API key (above)

You will also need a SuperMAG username (http://supermag.jhuapl.edu/),
and an AMPERE username (http://ampere.jhuapl.edu/).

Using your terminal navigate to the directory where you cloned 
the AMGeO Git repository and run the configuration script:

.. code::

	python configure.py

The script will ask you for:

#. Your AMGeO API key
#. Your SuperMAG username
#. Your AMPERE username

Run
---

To make a basic AMGeO plot do the following:

.. code::

	python driver_default.py 2015 3 17 N --hour 3 --minute 2 --second 30

A plot of the AMGeO result for 3-17-2015 03:00 - 03:05 will be added to your
home directory in a folder called amgeo_v1_output.

To run an entire day and save the results into an HDF5 file:

.. code::
	
	python driver_default.py 2015 3 17 N

To run using Iridium observations to solve for field-aligned current:

.. code::
	
	python driver_default.py 2015 3 17 N --mpot --mpoteofkind cme

.. warning::
	Magnetic potential / field-aligned current solver is a work-in-progress.
	Use `--mpoteofkind cme` when running AMGeO for geomagnetically active
	intervals and `--mpoteofkind all` otherwise.

To see all available commands

.. code::

	python driver_default.py --help

.. note::

	AMGeO needs both SuperDARN and SuperMAG data, so check that the date you
	are interested in has data available at the individual data providers.
	If the data is downloadable from SuperMAG (http://supermag.jhuapl.edu) 
	and there are 'grid2' data files available from SuperDARN (http://vt.superdarn.org/tiki-index.php?page=Data+Inventory), 
	AMGeO should be able to run.


	