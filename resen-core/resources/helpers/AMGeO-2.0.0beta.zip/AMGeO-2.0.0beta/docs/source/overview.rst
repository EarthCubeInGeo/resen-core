Overview of AMGeO process
=========================

The following flowcharts summarize some aspects of the AMGeO workflow
which occurs when data is gathered, processed and used to adjust the
background model prediction in an optimal way.

Ingest and Prediction
---------------------

This (large) flowchart shows the overall process that is going on
'under the hood' in AMGeO.

.. image:: _static/IngestPrediction_Conductance_Simplfied.svg

SuperMAG Processing
-------------------

This flowchart details the preparation of SuperMAG data. It makes up part of 
the upper-left-most dotted box in the the large flowchart.

.. image:: _static/SuperMAG_Observation_Prep_Apex.svg
	:width: 800px

SuperDARN Processing
--------------------

This flowchart correspondingly details the SuperDARN preperation.
It makes up part of the upper-left-most dotted box in the the large flowchart.

.. image:: _static/SuperDARN_Observation_Prep.svg
	:width: 700px

AMPERE/Iridium Processing
-------------------------

Flowchart will be added soon.