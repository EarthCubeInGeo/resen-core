#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import pytest
import shutil,tempfile,datetime
from numpy import testing as nptest
import numpy as np
from AMGeO.observations.ampere import Ampere
from AMGeO.driver_default import _default_conductance_model
from AMGeO.basis import physics

def to_phi_theta(H):
    H_ph = physics._component_array_from_3D_array(H,'eastward')
    H_th = physics._component_array_from_3D_array(H,'equatorward')
    return H_ph,H_th

def _date():
    #return datetime.datetime(2011,11,26)
    return datetime.datetime(2015,3,20)

def _time_range():
    startdt=_date()+datetime.timedelta(hours=0,minutes=0)
    enddt=_date()+datetime.timedelta(hours=0,minutes=10)
    return startdt,enddt

def _amp_instance():
    asim_date = _date()
    return Ampere(asim_date,False)

@pytest.fixture(scope='module')
def amp_instance(request):
    return _amp_instance()

def test_get_data_window(amp_instance):
    """This is a basic 'does it run' test."""
    startdt,enddt = _time_range()
    data_window_args = (startdt,enddt,'N','all')
    datadict,metadata = amp_instance.get_data_window(*data_window_args)
    assert np.any(datadict['data_eastward']!=0.)
    #test if the nan filter worked 
    assert np.all(np.isfinite(datadict['data_eastward']))

def test_obs_to_basis(amp_instance):

    startdt,enddt = _time_range()
    data_window_args = (startdt,enddt,'N','all')

    H_E,H_meta = amp_instance.get_obs_to_basis(*data_window_args)
    H_ph,H_th = to_phi_theta(H_E)

    #check if shapes are the same 
    assert 244 == np.shape(H_ph)[1]


def test_get_ingest_data(amp_instance):

    startdt,enddt = _time_range()
    data_window_args = (startdt,enddt,'N','all')

    ylats,ylons,y,y_var,obs_to_basis,ymeta =  amp_instance.get_ingest_data(*data_window_args)

    H_ph,H_th = to_phi_theta(obs_to_basis)

    #check if shape of obs matches shape of obs_to_basis
    assert (len(y[:,0]),244) == np.shape(H_ph)
