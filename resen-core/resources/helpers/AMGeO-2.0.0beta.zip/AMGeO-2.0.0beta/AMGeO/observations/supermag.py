#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
from collections import OrderedDict
from geospacepy import special_datetime, satplottools
from nasaomnireader.omnireader import omni_interval
import numpy as np
import matplotlib.pyplot as pp
import datetime, os, timeit, random
import h5py
import logbook

from AMGeO.files.directories import tables_dir,data_dir
from AMGeO.datamodel.record import RecordMetadata
from AMGeO.basis.interface import ModelDependantBasisPhysicsFunction
from AMGeO.basis.physics import get_ground_magnetic_perturbations,_3D_components

from AMGeO.downloaders.supermag import download_supermag_data

from AMGeO.observations.locations import ObservationApexLocations
from AMGeO.observations.exceptions import DataWindowBoundaryError
from AMGeO.observations.exceptions import NoDataAvailableError

log = logbook.Logger('AMGeO.observations.supermag')

class SuperMAG(object):
    """
    An observations class for SuperMAG ground magnetometer data
    """
    def __init__(self,dt,conductance_model):
        """Create a container for one day of SuperMAG ground magnetic
        perturbation data from an ASCII file downloaded from SuperMAG
        website


        Parameters
        ----------.
        supermag_file : str
            Path to a ASCII format standard SuperMAG data file
            (as download from website)
        conductance_model : object
            A model from AMGeO.models.conductance

        Raises
        ------
        ValueError
            If no SuperMAG file passed
        """
        self.name = 'SuperMAG'
        self.dt = dt
        self.components = _3D_components

        self.basis_physics_function = ModelDependantBasisPhysicsFunction(conductance_model,
                                            get_ground_magnetic_perturbations)

        #Default to observers file current as of 9-29-2017
        observers_csv = os.path.join(tables_dir,
                                'test_amgeo_obs',
                                'supermag-stations.csv')

        #Load SuperMAG observer info from a observers file
        self.observers = self.parse_observers_csv(observers_csv)

        #Look in default location for ASCII supermag file
        supermag_file = os.path.join(data_dir,
                                '%d%.2d%.2d-supermag.txt' % (self.dt.year,
                                                            self.dt.month,
                                                            self.dt.day))


        if not os.path.exists(supermag_file):
            log.notice(('No file {}\n'.format(supermag_file)
                  +'Attempting to download '
                  +'SuperMAG data for {}...'.format(self.dt)))
            download_supermag_data(self.dt.year,
                                    self.dt.month,
                                    self.dt.day)
        else:
            log.notice('Loading SuperMAG file {}'.format(supermag_file))

        #Load a SuperMAG ASCII file downloaded from website
        vals = self.parse_ascii(supermag_file)
        dts_lst,jds,mlats,mlts,Bn,Be,Bz,sza,decl,symh,asyh,observer_cols = vals

        apexB = self.remove_ring_current_and_rotate_to_apex(dts_lst,jds,
                                            mlats,mlts,
                                            Bn,Be,Bz,
                                            sza,decl,symh,asyh,
                                            observer_cols)
        apexlocs,Bd1,Bd2,Bd3 = apexB

        n_times = len(dts_lst)
        n_stations = len(observer_cols.keys())

        self.observer_cols = observer_cols #which column matches which IAGA code

        #dts_lst is a list of datetime.datetime objects, one for each
        #minute of data (if made an array its shape is (n_records,))
        self.record_dts=np.array(dts_lst)
        self.record_jds=special_datetime.datetimearr2jd(self.record_dts)

        #Assign data variables (indexable with get_data_window_mask)
        #These come out as n_records x n_observers
        #(yes, including jds)
        self['jds'] = jds
        self['lats'],self['mlts'] = apexlocs.lats,apexlocs.mlts
        self['lons']= apexlocs.mlts/12*180. #Not really magnetic longitude
        self['dBd1'] = self['data_eastward'] = Bd1 #Magnetic East
        self['dBd2'] = self['data_equatorward'] = Bd2 #Magnetic Equatorward
        self['dBd3'] = self['data_fieldaligned']= Bd3 #Main Field Aligned

        #Additional (non-ingest) data variables
        self['decl']=decl #Degs E of geo N of station mag N (calc by SuperMAG)

        self._metadata = RecordMetadata('gdB',
                                        'Ground Magnetic Perturbations',
                                        'nT',
                                        validmin=-3000.,
                                        validmax=3000.,
                                        typicalvalue=300.)

        #Minimum latitude for observers we will use
        #Need this to prevent apex coord transform from failing
        self.minlat = 50.

        #Default observation error setting [nT]
        self.default_obs_err = 50.

    def _time_bounds_str(self):
        dtfmt = '%Y/%m/%d %H:%M:%S'
        tstr = '%s-%s' % (self.record_dts[0].strftime(dtfmt),
                            self.record_dts[-1].strftime(dtfmt))
        return tstr

    def _window_time_bounds_str(self,startdt,enddt):
        dtfmt = '%Y/%m/%d %H:%M:%S'
        tstr = '%s-%s' % (startdt.strftime(dtfmt),
                            enddt.strftime(dtfmt))
        return tstr

    def __str__(self):
        return 'SuperMAG {}'.format(self._time_bounds_str())

    # def __str__(self):
    #     """
    #     Describe this object

    #     Returns
    #     -------
    #     str
    #         String showing hemisphere, start, and end times of data retrived
    #         by a call to get_ingest_data
    #     """
    #     return "SuperMAG %sH %s" % (self.hemi,self._window_time_bounds_str())

    def __setitem__(self,item,value):
        if not hasattr(self,'_observation_data'):
            self._observation_data = OrderedDict()
        self._observation_data[item]=value

    def __getitem__(self,item):
        return self._observation_data[item]

    def __contains__(self,item):
        return item in self._observation_data

    def __iter__(self):
        for item in self._observation_data:
            yield item

    def items(self):
        for key,value in self._observation_data.items():
            yield key,value

    def _get_time_mask(self,startdt,enddt):
        """Mask for which rows of data array represent times between
        startdt and enddt
        """
        startjd = special_datetime.datetime2jd(startdt)
        endjd = special_datetime.datetime2jd(enddt)
        if endjd<self.record_jds[0] or startjd>self.record_jds[-1]:
            dtcode = '%Y/%m/%d %H:%M:%S'
            dts = (startdt,enddt)
            raise DataWindowBoundaryError(('Time range '
                                            +self._window_time_bounds_str(*dts)
                                            +'is out of range for data '
                                            +'in SuperMAG object '
                                            +self._time_bounds_str()))

        return np.logical_and(self.record_jds.flatten()>=startjd,
                            self.record_jds.flatten()<endjd)

    def _get_hemisphere_mask(self,hemisphere):
        """Mask for which columns of the data array represent observers
        in the desired hemisphere
        """
        if hemisphere is None or hemisphere not in ['N','S']:
            raise ValueError('Hemisphere must be N or S!')
        #Since self.mlats has shape (n_records,n_observers)
        # we will just take first row since mlat of mags does not
        # change with time
        if hemisphere is 'N':
            inhemi = self['lats'][0,:].flatten() > self.minlat
        elif hemisphere is 'S':
            inhemi = self['lats'][0,:].flatten() < -1*self.minlat
        return inhemi

    def _check_allowed_observers(self,allowed_observers):
        """Check that list of iaga codes allowed_observers contains real
        IAGA codes only, also warn if observer for any IAGA code in
        allowed_observers is not available for this day of data
        """
        if not isinstance(allowed_observers,list):
            raise ValueError('allowed_observers must be a list of IAGA codes')
        use_iagas = []
        for iaga in allowed_observers:
            if iaga not in self.observers.keys():
                log.warning( "Warning: %s is not a valid iaga code" % (str(iaga)))
            elif iaga not in self.observer_cols.keys():
                log.warning("Warning: SuperMAG observer %s " % (str(iaga)),
                            +"selected in allowed_observers not available")
            else:
                use_iagas.append(iaga)
        return use_iagas

    def _get_observers_mask(self,allowed_observers):
        """Mask for which columns in data array represent observers
        with iaga codes in the list of iaga code allowed_observers
        """
        if allowed_observers!='all':
            use_iagas = self._check_allowed_observers(allowed_observers)
            touse = np.zeros((len(self.observer_cols.keys()),),dtype=bool)
            for iaga in use_iagas:
                touse[self.observer_cols[iaga]]=True
        else:
            #Use all available observers
            touse = np.ones((len(self.observer_cols.keys()),),dtype=bool)

        return touse

    def get_data_window_mask(self,startdt,enddt,hemisphere,allowed_observers):
        """Get a mask which represents all useable (non-NaN) data between
        times startdt and enddt, in hemisphere hemsphere, and only
        including magnetometers with IAGA codes in list allowed_observers
        """

        #Valid rows of data are easy and don't require bad or missing value
        #filtering
        intime = self._get_time_mask(startdt,enddt)
        userows = intime

        #Determine valid columns of data
        inhemi = self._get_hemisphere_mask(hemisphere)
        touse = self._get_observers_mask(allowed_observers)

        usecols = np.logical_and(inhemi,touse)

        #Determine if any columns have all NaN rows
        #for positions or magnetic perturbations
        #and add these to column mask
        for data_var_name in ['lats','lons','dBd1','dBd2','dBd3']:
            data_var = self[data_var_name]
            rowwise_median_data_var = np.nanmedian(data_var[userows,:],axis=0)
            usecols = np.logical_and(usecols,np.isfinite(rowwise_median_data_var))

        return userows,usecols

    def get_data_window(self,startdt,enddt,hemisphere,allowed_observers):
        """Return an ordered dictionary of all observation data variables
        which represents the values of each variable for times in
        [startdt,enddt), above 50 degrees latitude in hemisphere,
        and with IAGA code in list allowed_observers (or all observers if
        allowed_observers is 'all')
        """
        userows,usecols = self.get_data_window_mask(startdt,enddt,
                                                        hemisphere,
                                                        allowed_observers)

        observation_data_window = OrderedDict()
        for varname,vardata in self.items():
            vardata_in_window = vardata[userows,:][:,usecols]
            #Take the median of each column (one value for each
            #station)
            observation_data_window[varname]=np.nanmedian(vardata_in_window,
                                                            axis=0).flatten()

        data_window_metadata = self._metadata.copy()
        data_window_metadata['window_startdt']=startdt
        data_window_metadata['window_enddt']=enddt
        data_window_metadata['window_allowed_observers']=allowed_observers

        return observation_data_window,data_window_metadata

    def get_obs_to_basis(self,startdt,enddt,hemisphere,allowed_observers):
        """

        Compute forward operator, H, a matrix with shape [n_obs,n_basis]
        which when (matrix) multiplied by a vector of AMGeO basis
        function weights,produces the trunctated expansion value for
        ground magntic perturbations at the locations of each of
        the n_obs observations

        Store H as a class property so that we don't have to recompute
        it if, for example,
        get_ingest_data is called more than once without changing
        datetime range (self.startdt and self.enddt),
        which determines which data gets selected by get_ingest_data

        Returns
        -------
        H : np.ndarray
            Forward operator
        Hmeta : RecordMetadata
            Metadata information about ground magnetic perturbations
        """

        datadict,metadata = self.get_data_window(startdt,enddt,hemisphere,allowed_observers)

        window_width_seconds = (enddt-startdt).total_seconds()
        dt = startdt+datetime.timedelta(seconds=int(window_width_seconds/2))

        lats = np.abs(datadict['lats']) #Basis functions always expect positive
        lons = datadict['lons']

        H,Hmeta = self.basis_physics_function(dt,hemisphere,lats,lons)

        return H,Hmeta

    def get_ingest_data(self,startdt,enddt,hemisphere,allowed_observers):
        """Formats the observations in the correct way so that they can be
        ingested into AMGeO

        Returns
        -------
        lats : np.ndarray
            Absolute magnetic latitudes of observations
        lons : np.ndarray
            AMGeO magnetic 'longitudes' (MLT in degrees) of observations
        y : np.ndarray
            1D array of magnetic perturbation observations
            (North component first, then East, then Upward)
        y_var : np.ndarray
            1D array of uncertainies (variances) in magnetic perturbations
            (i.e. diagonal of observation error covariance matrix)
        obs_to_basis : np.ndarray
            1D array that represents magnetic perturbations as AMGeO basis
            function coefficients (same component order as above)
        ymeta : RecordMetadata
            Metadata information (including data window extra attributes)
        """
        obs_err = self.default_obs_err

        datadict,metadata = self.get_data_window(startdt,enddt,hemisphere,allowed_observers)

        #Format the vector measurements as a 1-D observation vector,
        #with each component as a seperate observation
        y = np.dstack([datadict['data_eastward'].reshape(-1,1),
                       datadict['data_equatorward'].reshape(-1,1),
                       datadict['data_fieldaligned'].reshape(-1,1)])

        #y_var = np.concatenate([.5*Bn[g],1.0*Be[g],.8*Bz[g]])*.3

        #Format the error/variance vector similarly,
        #this will be the diagonal of C_b / R, representativeness/observation
        #covariance
        #Cousins et. al. 2015 number of observations scaling factor,
        #as used for AMPERE
        #nfac = float(len(lats))**.25
        #y_var = nfac*(np.ones_like(y)*obs_err**2)

        y_var = np.ones_like(y)*obs_err**2

        #Get H for magnetic perturbations
        #Coordinate order is north,east,down
        H,Hmeta = self.get_obs_to_basis(startdt,enddt,
                                                hemisphere,allowed_observers)

        #Obs to basis is also called forward operator H
        #Order is East, Equatorward, Vertical/Field Aligned
        obs_to_basis = H

        #Locations for each vector component
        ylats = datadict['lats']
        ylons = datadict['lons']

        ymeta = metadata

        return np.abs(ylats),ylons,y,y_var,obs_to_basis,ymeta

    def plot_vectors(self,ax,startdt,enddt,hemisphere,allowed_observers,
                    prediction=None,scatter=True,**kwargs):
        """
        Plot the magnetometer observations at their locations
        on a polar plot

        Parameters
        ----------
        ax : matplotlib.axes
            Axes on which we will plot
        hemi : str
            N or S, hemisphere (deprecated)
        prediction : AMGeO.update.assimilate.Prediction
            plot a prediction
        scatter : bool, optional
            Switch to draw dots at observation locations
            as well as vectors
        """

        datadict,metadata = self.get_data_window(startdt,enddt,hemisphere,allowed_observers)
        lats = datadict['lats']
        lons = datadict['lons']

        B_east = datadict['data_eastward']
        B_eq = datadict['data_equatorward']

        #Cartesian locations
        X,Y = satplottools.latlon2cart(lats,lons,hemisphere)

        theta = lons-90.
        theta[theta>180.]-=360.
        theta[theta<-180.]+=360.
        theta = np.radians(theta)

        eq_hat_x,eq_hat_y = np.cos(theta),np.sin(theta)
        east_hat_x,east_hat_y = -1.*np.sin(theta),np.cos(theta)

        #Convert vectors to cartesian from top-down polar
        B_x = B_east*east_hat_x + B_eq*eq_hat_x
        B_y = B_east*east_hat_y + B_eq*eq_hat_y

        g = np.logical_and(np.logical_not(np.isnan(B_x)),
                            np.logical_not(np.isnan(B_y)))

        color = 'black' if 'color' not in kwargs else kwargs['color']

        if scatter:
            if 'scatter_color' not in kwargs:
                kwargs['scatter_color']='black'
            ax.scatter(X[g],Y[g],2,color=kwargs['scatter_color'],alpha=.8)

        medval = np.nanmean(np.sqrt(B_x[g]**2+B_y[g]**2))
        low = np.sqrt(B_x[g]**2+B_y[g]**2)<medval
        high = np.sqrt(B_x[g]**2+B_y[g]**2)>=medval

        if 'key_vector_magnitude' in kwargs:
            key_vec_mag = kwargs['key_vector_magnitude']
        elif 'typicalvalue' in metadata:
            key_vec_mag = metadata['typicalvalue']
        else:
            key_vec_mag = 400.

        Ql = ax.quiver(X[g][low], Y[g][low], B_x[g][low], B_y[g][low],
            color=color, angles='xy', scale_units='xy', scale=key_vec_mag/10.,
            alpha=.4, headwidth=1., headlength=1.,width=.004)
        Qh = ax.quiver(X[g][high], Y[g][high], B_x[g][high], B_y[g][high],
            color=color,angles='xy', scale_units='xy', scale=key_vec_mag/10.,
            alpha=.8, headwidth=1., headlength=1.,width=.005)

        ax.quiverkey(Qh,.75,0.9,key_vec_mag,'%d nT' % (key_vec_mag))

    def parse_observers_csv(self,fn,n_header_lines=1):
        """Parse a SuperMAG CSV observer info data file into a dict


        Parameters
        ----------
        fn : str
            filename to load
        n_header_lines : int, optional
            number of header lines

        Returns
        -------
        TYPE
            Description

        """
        #File header
        #IAGA,GLON,GLAT,MLON,MLAT,STATION-NAME,OPERATOR-NUM,OPERATORS
        field_info = [{'name':'iaga','typefun':str},
                    {'name':'glon','typefun':float},
                    {'name':'glat','typefun':float},
                    {'name':'mlon','typefun':float},
                    {'name':'mlat','typefun':float},
                    {'name':'observer-name','typefun':str},
                    {'name':'operator-num','typefun':str},
                    {'name':'operators','typefun':str}]

        observers = OrderedDict()

        log.info('Reading SuperMAG Stations CSV file {}...'.format(fn))

        #Begin reading
        lnnum=0
        with open(fn,'r') as f:
            #Skip 1 line of header
            while lnnum < n_header_lines:
                f.readline()
                lnnum+=1
            while True:
                #Read record description
                #year,month,day,hour,minute,second,n_observers
                recln = f.readline()
                if recln is None or not recln or recln.isspace():
                    #end of file
                    break
                rec_dict = {}

                #Deal with comma in operators field
                #(i.e. multiple magnetometer operators)
                raw_fields = recln.split(',')
                if len(raw_fields)>len(field_info):
                    fields = raw_fields[:len(field_info)]
                    for extra in raw_fields[len(field_info):]:
                        last = fields[-1]
                        fields[-1] = last+','+extra
                else:
                    fields = raw_fields

                for ifield,fieldstr in enumerate(fields):
                    key = field_info[ifield]['name']
                    val = field_info[ifield]['typefun'](fieldstr)
                    rec_dict[key]=val


                observers[rec_dict['iaga']]=rec_dict
        return observers

    def parse_ascii(self,fn,n_header_lines=71,max_observers=320,max_records=1440):
        """Parse a SuperMAG ASCII data file into a table/2D array of data
        with records in rows and observers in columns


        Parameters
        ----------
        fn : TYPE
            Description
        n_header_lines : int, optional
            Description
        max_observers : int, optional
            Description
        max_records : int, optional
            Description

        Returns
        -------
        TYPE
            Description

        .. note::
        Don't currently know how many observers to use for max.
        SuperMAG website says 'more than 300'.
        Records are 1 per minute

        """
        log.notice('Reading SuperMAG ASCII data file {}'.format(fn))

        #Dictionary with observer
        #IAGA identifiers as keys and
        #column in which to store their data in values
        observer_cols = dict()
        lnnum = 0 # Line number counter
        rcnum = 0 # Record number counter

        #Preallocate arrays
        rec_dts,rec_jds = [],[]
        jd = np.full((max_records,max_observers),np.nan) #Julian date
        Bn = np.full((max_records,max_observers),np.nan)
        Be = np.full((max_records,max_observers),np.nan)
        Bz = np.full((max_records,max_observers),np.nan)
        mlat= np.full((max_records,max_observers),np.nan)
        mlt = np.full((max_records,max_observers),np.nan)
        mlon = np.full((max_records,max_observers),np.nan)
        sza = np.full((max_records,max_observers),np.nan)
        decl = np.full((max_records,max_observers),np.nan)

        record_info = {'B_N':{'RecCol':0,'Arr':Bn},
                        'B_E':{'RecCol':1,'Arr':Be},
                        'B_Z':{'RecCol':2,'Arr':Bz},
                        'MLT':{'RecCol':3,'Arr':mlt},
                        'MLAT':{'RecCol':4,'Arr':mlat},
                        'SZA':{'RecCol':6,'Arr':sza},
                        'DECL':{'RecCol':5,'Arr':decl}}

        #Begin reading
        with open(fn,'r') as f:
            #Skip variable number of lines of header...seems to change
            #used to be 71 but they added a 'Data revision' line

            #Last header line is line of = charaters
            lnnum=0
            while f.readline().find('====')==-1:
                lnnum+=1

            if lnnum!=n_header_lines:
                log.warning(("SuperMAG file header format mismatch\n"
                            +"Expected %d lines\n" % (n_header_lines)
                            +"Read %d line" % (lnnum)))

            while True:
                #Read record description
                #year,month,day,hour,minute,second,n_observers
                recln = f.readline()
                if recln is None or not recln or recln.isspace():
                    #end of file
                    break
                else:
                    #Empty strings are 'falsy' so ( if x ) is False if x == ''
                    rec_desc = [int(x) \
                                for x in recln.split() \
                                if (x and not x.isspace())]
                    year,month,day,hour,minute,second,n_observers = rec_desc[:]
                    rec_dt = datetime.datetime(year,month,day,
                                                hour,minute,second)
                    rec_jd = special_datetime.datetime2jd(rec_dt)
                    #Read data for observers for this time
                    for i_ln in range(n_observers):
                        ln = f.readline()
                        lnlst = [x.strip() \
                                for x in ln.split() \
                                if (x and not x.isspace())]
                        observer_name = lnlst[0]
                        recdata = [float(x) if \
                                    x.strip() is not '999999' \
                                    else np.nan for x in lnlst[1:] ]
                        if observer_name in observer_cols:
                            col = observer_cols[observer_name]
                        else:
                            col = len(observer_cols.keys())
                            observer_cols[observer_name] = col
                        jd[rcnum,col] = rec_jd
                        for var in record_info:
                            vararray = record_info[var]['Arr']
                            rcol = record_info[var]['RecCol']
                            if np.abs(recdata[rcol])>90000.:
                                recdata[rcol]=np.nan
                            vararray[rcnum,col]=recdata[rcol]

                    rec_dts.append(rec_dt)
                    rec_jds.append(rec_jd)
                    rcnum += 1

        # Total number of columns which have one or more row of data
        nmags = len(observer_cols.keys())

        #Get 1-minute SYM-H from omniweb
        oi = omni_interval(rec_dts[0]-datetime.timedelta(hours=12),
                                    rec_dts[-1]+datetime.timedelta(hours=12),
                                    '1min')
        ojd = special_datetime.datetimearr2jd(oi['Epoch']).flatten()
        osymh = oi['SYM_H'].flatten()
        oasyh = oi['ASY_H'].flatten()

        o2sm = np.array(
                [np.nanargmin(ojd-rec_jds[i]) for i in range(len(rec_jds))])
        symh = osymh[o2sm]
        symhbloc = np.tile(symh,(1,nmags))

        asyh = osymh[o2sm]
        asyhbloc = np.tile(symh,(1,nmags))

        return (rec_dts[:rcnum],jd[:rcnum,:nmags],
                mlat[:rcnum,:nmags],mlt[:rcnum,:nmags],
                Bn[:rcnum,:nmags],Be[:rcnum,:nmags],Bz[:rcnum,:nmags],
                sza[:rcnum,:nmags],decl[:rcnum,:nmags],symhbloc[:rcnum,:nmags],
                asyhbloc[:rcnum,:nmags],
                observer_cols)

    def remove_ring_current_and_rotate_to_apex(self,dts,jds,mlats,mlts,Bn,Be,Bz,
                                                    sza,decl,symh,asyh,
                                                    observer_cols,
                                                    remove_ring_current=True):
        """Remove DST and rotate SuperMAG observations from local geomagnetic
        to Magnetic Apex

        """
        #MATLAB code to remove DST and rotate to geocentric
        # symh = omni_symH_symD(:,8);
        # symhbloc = repmat(symh',219,1);
        # BH = sqrt(BN.^2 + BE.^2); angle = atan2(BN,BE);
        # BHr = BH - symhbloc.*cos(MLAT.*pi/180); ind = BHr < 0; BHr(ind) = 0;
        # BEr = BHr.*cos(angle); ind = BE == 999999; BEr(ind) = 999999;
        # BNr = BHr.*sin(angle); ind = BN == 999999; BNr(ind) = 999999;
        # C = 0.3;
        # BZr = BZ + C*symhbloc.*sin(MLAT.*pi/180); ind = BZ == 999999; BZr(ind) = 999999;

        # %Step3: rotate BN, BE in magnetic coordinates to BX, BY in geographic coordinates

        # BXr = BHr.*cos(DECL);
        # BYr = BHr.*sin(DECL);
        n_recs = Bn.shape[0]
        n_observers = Bn.shape[1]

        #Get geo locations
        observer_glats = np.full((n_observers,),np.nan)
        observer_glons = np.full((n_observers,),np.nan)
        observer_iagas = []

        for iaga in observer_cols:
            i_observer = observer_cols[iaga]
            observer_glats[i_observer] = self.observers[iaga]['glat']
            observer_glons[i_observer] = self.observers[iaga]['glon']
            observer_iagas.append(iaga)

        Bh = np.sqrt(Bn**2+Be**2)
        angle = np.arctan2(Bn,Be)

        if remove_ring_current:
            Bh_corr = Bh - symh*np.cos(mlats*np.pi/180.)
            Bh_corr[Bh_corr<0]=0.
            Be_corr = Bh_corr*np.cos(angle)
            Bn_corr = Bh_corr*np.sin(angle)
            #C  0.2-0.5
            C=0.3 #arbitrary
            Bz_corr = Bz + C*symh*np.sin(mlats*np.pi/180.)
        else:
            Be_corr = Be
            Bn_corr = Bn
            Bz_corr = Bz
            Bh_corr = Bh

        Bu_geo = -1.*Bz_corr

        # I think this is right (ENU Geo)?
        #Be_geo = Bh_corr*np.cos(decl/180.*np.pi)
        #Bn_geo = Bh_corr*np.sin(decl/180.*np.pi)

        #Testing the other way (NED Geo)
        #Bn_geo = Bh_corr*np.cos(decl/180.*np.pi)
        #Be_geo = Bh_corr*np.sin(decl/180.*np.pi)

        #Euler angle version (ENU) rotate counterclockwise
        #declrad = decl/180.*np.pi
        #Be_geo = Be_corr*np.cos(declrad)-Bn_corr*np.sin(declrad)
        #Bn_geo = Be_corr*np.sin(declrad)+Bn_corr*np.cos(declrad)

        #Euler angle version NED (positive dec is east of north),
        #in NED we need to rotate clockwise instead of counterclockwise
        declrad = decl/180.*np.pi
        Bn_geo = Bn_corr*np.cos(-1.*declrad)-Be_corr*np.sin(-1.*declrad)
        Be_geo = Bn_corr*np.sin(-1.*declrad)+Be_corr*np.cos(-1.*declrad)


        observer_alts = np.ones_like(observer_glats)
        igrf_epoch = dts[0].year
        apexlocs = ObservationApexLocations(dts,
                                            observer_glats,
                                            observer_glons,
                                            observer_alts,
                                            igrf_epoch,
                                            tile_locs_to_dts=True,
                                            altmin=1.,
                                            altmax=200.,
                                            hr=5.) # Why reference height 5?

        #Get observations in apex
        Bd1 = (Be_geo*np.tile(apexlocs.e1[:,0],(n_recs,1))
                + Bn_geo*np.tile(apexlocs.e1[:,1],(n_recs,1))
                + Bu_geo*np.tile(apexlocs.e1[:,2],(n_recs,1)))

        Bd2 = (Be_geo*np.tile(apexlocs.e2[:,0],(n_recs,1))
                + Bn_geo*np.tile(apexlocs.e2[:,1],(n_recs,1))
                + Bu_geo*np.tile(apexlocs.e2[:,2],(n_recs,1)))

        Bd3 = (Be_geo*np.tile(apexlocs.e3[:,0],(n_recs,1))
                + Bn_geo*np.tile(apexlocs.e3[:,1],(n_recs,1))
                + Bu_geo*np.tile(apexlocs.e3[:,2],(n_recs,1)))

        debug=False
        if debug:

            def debug_print(i,istat):
                print('t',i)
                hs = np.sign(apexlocs.lats[i,istat])
                print(apexlocs.lats[i,istat],apexlocs.mlts[i,istat])
                print('Declination',decl[i,istat])
                print('Local ENU ',Be[i,istat],Bn[i,istat],-1*Bz[i,istat])
                print('Corr ENU ',Be_corr[i,istat],Bn_corr[i,istat],-1*Bz_corr[i,istat])
                print('Geo ENU ',Be_geo[i,istat],Bn_geo[i,istat],Bu_geo[i,istat])
                print('Apex d ',Bd1[i,istat],Bd2[i,istat],Bd3[i,istat])
                print('e1:',apexlocs.e1[istat,0],apexlocs.e1[istat,1],apexlocs.e1[istat,2])
                print('e2:',apexlocs.e2[istat,0],apexlocs.e2[istat,1],apexlocs.e2[istat,2])
                print('e3:',apexlocs.e3[istat,0],apexlocs.e3[istat,1],apexlocs.e3[istat,2])

            istat = observer_cols['BRW']
            if dts[0].year == 2015 and dts[0].month == 3 and dts[0].day == 16:
                for i in range(n_recs):
                    if dts[i].hour == 3 and dts[i].minute == 0:
                        debug_print(i,istat)

                #raise RuntimeError('Debug Stop')

        return apexlocs,Bd1,Bd2,Bd3
