#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
from collections import OrderedDict
from geospacepy import special_datetime, satplottools
from nasaomnireader.omnireader import omni_interval

import numpy as np
import matplotlib.pyplot as pp
import datetime, os, timeit, random
import h5py
import logbook

from AMGeO.basis.physics import get_ion_velocity,get_electric_field
from AMGeO.basis.physics import _component_array_from_3D_array
from AMGeO.files import directories
from AMGeO.downloaders.superdarn import download_superdarn_data
from AMGeO.datamodel.record import RecordMetadata
from AMGeO.observations.exceptions import DataWindowBoundaryError
from AMGeO.observations.exceptions import NoDataAvailableError

log = logbook.Logger('AMGeO.observations.superdarn')

class SuperDARN(object):
    """A class for SuperDARN Line-of-Sight Ion convection data
    making use of functions within the Just SAM project to get the convection
    velocities

    Attributes
    ----------
    basisset : TYPE
        Description
    bigrfs : TYPE
        Description
    enddt : TYPE
        Description
    hemi : TYPE
        Description
    ingest_var : str
        Description
    minlat : float
        Description
    n_recs : TYPE
        Description
    n_vector_components : int
        Description
    name : str
        Description
    jds : TYPE
        Description
    startdt : TYPE
        Description
    observer_ids : TYPE
        Description
    """
    def __init__(self,dt,hemisphere,observation_type='electricfield'):
        """
        Contain a day of superDARN data for date in datetime dt

        Parameters
        ----------
        dt : datetime.datetime
            What day of data to get
        hemisphere : str, optional
            What hemisphere's data will be loaded (SuperDARN data is
            packaged seperately for each hemisphere)
        observation_type : str,optional
        """
        self.name = 'SuperDARN'

        self.hemisphere = hemisphere

        self.observation_type = observation_type

        self.year,self.month,self.day = dt.year,dt.month,dt.day

        self.components = None #Data returns as line of sight

        daydata = self.readDayHDF5(dt,hemisphere)

        recordinds = daydata[0]
        startdts,enddts,centerdts,centerjds = daydata[1:5]
        lats,mlons,mltlons = daydata[5:8]
        vels,verrs,eloss,eerrs,azms,rids,bigrfs = daydata[8:]

        #All of these are 1D arrays

        self['recordinds']=recordinds
        self['startdts'],self['enddts'] = startdts,enddts

        self['dts'],self['jds'] = centerdts,centerjds
        self['lats'],self['lons'] = lats,mltlons
        self['angle_los']=azms

        if observation_type is 'electricfield':
            self['data_los'],self['errs_los'] = eloss,eerrs
            u_ph,u_th=self._data_direction_eastward_equatorward(azms,
                                                                hemisphere,
                                                                'E')


            self['data_unit_vec_eastward'] = u_ph
            self['data_unit_vec_equatorward'] = u_th

            self['data_eastward'] = u_ph*eloss
            self['data_equatorward'] = u_th*eloss

            self._basis_physics_function = get_electric_field
            self._metadata = RecordMetadata('elos',
                                            ('Electric Field'
                                            +'From SuperDARN Line-of-Sight'
                                            +'Ion Drift Velocity'),
                                            'V/m',
                                            validmin=-60./1000.,
                                            validmax=60./1000,
                                            typicalvalue=30./1000,
                                            hemisphere=self.hemisphere)

        elif observation_type is 'iondriftvelocity':
            self['data_los'],self['errs_los'] = vels,verrs

            u_ph,u_th=self._data_direction_eastward_equatorward(azms,
                                                                hemisphere,
                                                                'v')
            self['data_unit_vec_eastward'] = u_ph
            self['data_unit_vec_equatorward'] = u_th

            self['data_eastward'] = u_ph*vels
            self['data_equatorward'] = u_th*vels

            self._basis_physics_function = get_ion_velocity
            self._metadata = RecordMetadata('vlos',
                                            ('SuperDARN Line-of-Sight'
                                            +'Ion Drift Velocity'),
                                            'm/s',
                                            validmin=-3000.,
                                            validmax=3000.,
                                            typicalvalue=500.,
                                            hemisphere=self.hemisphere)
        else:
            raise ValueError('observation_type {} '.format(observation_type)
                             +'is invalid, valid values are '
                             +'electricfield and iondriftvelocity')

        self['observer_ids'] = rids
        self['bigrfs'] = bigrfs

        #This is a list of all observers present during this day
        self.all_observers = np.unique(self['observer_ids']).tolist()

        self.minlat = 50.

        log.info('Created SuperDARN observation object {}'.format(str(self)))

    def __str__(self):
        return '{} {}:\n hemisphere {},\n date {}-{}-{}'.format(self.name,
                                                        self.observation_type,
                                                        self.hemisphere,
                                                        self.year,
                                                        self.month,
                                                        self.day)

    def __setitem__(self,item,value):
        if not hasattr(self,'_observation_data'):
            self._observation_data = OrderedDict()
        self._observation_data[item]=value

    def __getitem__(self,item):
        return self._observation_data[item]

    def __contains__(self,item):
        return item in self._observation_data

    def __iter__(self):
        for item in self._observation_data:
            yield item

    def items(self):
        for key,value in self._observation_data.items():
            yield key,value

    def _time_bounds_str(self):
        dtfmt = '%Y/%m/%d %H:%M:%S'
        tstr = '%s-%s' % (self.dts[0].strftime(dtfmt),
                            self.dts[-1].strftime(dtfmt))
        return tstr

    def _window_time_bounds_str(self,startdt,enddt):
        dtfmt = '%Y/%m/%d %H:%M:%S'
        tstr = '%s-%s' % (self.startdt.strftime(dtfmt),
                            self.enddt.strftime(dtfmt))
        return tstr

    @staticmethod
    def _data_direction_eastward_equatorward(azm,hemisphere,E_or_v):
        """Determine the components in eastward (phi), equatorward (theta)
        of the unit vector in the direction of a
        SuperDARN ion drift velocity or electric field
        observation with radar line-of-sight direction specified by
        angle azm, where azm=0 is magnetic northward
        and azm is positive to the east of north.
        Because the relationship of magnetic northward with magnetic
        equatorward (theta) is hemisphere dependent, hemisphere = 'N' or 'S'
        must also be supplied (additionally the sense of the vertical component
        of the phi/theta coordinate system changes with hemisphere, which
        matters for the calculation of E (cross product must be
        computed using 3 vector components).

        Inputs
        ------
            azm - numpy.ndarray, shape=(n_obs,)
                Line of sight angle, in degrees, where
                azm=0 is magnetic northward
                [0,90] is northeast quadrant
                [90,180] is southeast quadrant
                [-180,-90] is southwest quadrant
                [-90,0] is northwest quadrant

        Returns
        -------

            azm_ph - numpy.ndarray, shape=(n_obs,)
                Component of unit vector paralell to observation vector in
                the eastward direction
            azm_th = numpy.ndarray, shape=(n_obs,)
                Component of unit vector paralell to observation vector in
                the equatorward direction

        """
        if E_or_v == 'v':
            # in ENU coordinates
            # v = <vsin(azm),vcos(azm),0>

            if hemisphere == 'N':
                #North
                #AMGeO coordinates (ph, th, B)
                # ph = E
                # th = -N
                # B = -U
                azm_ph   = np.sin(np.radians(azm))
                azm_th   = -1*np.cos(np.radians(azm))
            elif hemisphere == 'S':
                #South
                #AMGeO coordinates (ph, th, B)
                # ph = E
                # th = N
                # B = U
                azm_ph   = np.sin(np.radians(azm))
                azm_th   = np.cos(np.radians(azm))

        elif E_or_v == 'E':

            if hemisphere == 'N':
                #In AMGeO coordinates (ph,th,B)
                #North
                #E = -v x B
                #  = - <vsin(azm),vcos(azm),0> x <0,0,B>
                #  = <vBcos(azm),vBsin(azm),0>
                azm_ph = np.cos(np.radians(azm))
                azm_th = np.sin(np.radians(azm))

            elif hemisphere == 'S':
                #In AMGeO coordinates (ph,th,B)
                #South
                #E = -v x B
                #  = - <vsin(azm),vcos(azm),0> x <0,0,B>
                #  = <-vBcos(azm),vBsin(azm),0>
                azm_ph = -np.cos(np.radians(azm))
                azm_th = np.sin(np.radians(azm))

        else:
            raise ValueError('{} must be "E" or "v"'.format(E_or_v))

        return azm_ph,azm_th

    # def __str__(self):
    #     """
    #     Describe the data returned by get_ingest_data

    #     Returns
    #     -------
    #     descstr - str
    #         String describing time and hemisphere of
    #         data get_ingest_data would return
    #         e.g.
    #         SuperDARN NH 2010/5/29 12:00 - 2010/5/29 12:04

    #     """
    #     return "SuperDARN %sH %s" % (self.hemi,self._window_time_bounds_str())

    def _get_time_mask(self,startdt,enddt):
        """Return mask in data arrays for all
        data in interval [startdt,enddt)"""
        startjd = special_datetime.datetime2jd(startdt)
        endjd = special_datetime.datetime2jd(enddt)
        if endjd<self['jds'][0] or startjd>self['jds'][-1]:
            dts = (startdt,enddt)
            raise DataWindowBoundaryError(('Data required for: '
                                          +self._window_time_bounds_str(*dts)
                                          +'out of range for SuperDARN object: '
                                          +self._time_bounds_str()))
        inrange = np.logical_and(self['jds'].flatten()>=startjd,
                                    self['jds'].flatten()<endjd)
        return inrange

    def _get_hemisphere_mask(self,hemisphere):
        if hemisphere not in ['N','S']:
            return ValueError(('{}'.format(hemisphere)
                              +' is not a valid hemisphere (use N or S)'))
        if hemisphere != self.hemisphere:
            raise DataWindowBoundaryError('hemisphere {}'.format(hemisphere)
                                          +' was requested but SuperDARN'
                                          +' object only contains data for'
                                          +' {}'.format(self.hemisphere)
                                          +' hemisphere.')
        inhemi = np.abs(self['lats']) > self.minlat
        return inhemi

    def _check_allowed_observers(self,allowed_observers):
        """Check that list of radar ID numbers allowed_observers is a list
        of numbers, and check if the specified RIDs are in any record in
        this days' data. Since we do not currently have a complete list of
        all valid RIDs we can't say whether or not a particular RID is invalid
        This is a TODO"""
        if not isinstance(allowed_observers,list):
            raise ValueError('allowed_observers must be a list of SuperDARN RIDS')
        rids_to_use = []
        for rid in allowed_observers:
            if not rid in self.all_observers:
                print(("Warning: %d may not be valid SuperDARN Radar ID" % (rid)
                      +" or the radar in question may not be available "))
            else:
                rids_to_use.append(rid)
        return rids_to_use

    def _get_observers_mask(self,allowed_observers):
        """Return 1D mask into data arrays from radars with RIDs in list of RIDs
        allowed_observers. If allowed_observers is None returns all-true mask
        (all radars allowed).
        """
        if allowed_observers!='all':
            rids_to_use = self._check_allowed_observers(allowed_observers)
        else:
            rids_to_use = self.all_observers

        all_radars_masks = []
        for rid in rids_to_use:
            all_radars_masks.append(self['observer_ids'].reshape(-1,1)==rid)

        observers_mask = np.any(np.concatenate(all_radars_masks,axis=1),axis=1)

        return observers_mask

    def get_data_window_mask(self,startdt,enddt,hemisphere,allowed_observers):
        """Return a 1D mask into the data arrays for all points in the
        specified time range, hemisphere and with radar IDs (RIDs) in
        list of RIDs allowed_observers"""
        mask = np.ones(self['jds'].shape,dtype=bool)
        mask = np.logical_and(mask,self._get_time_mask(startdt,enddt))
        mask = np.logical_and(mask,self._get_hemisphere_mask(hemisphere))
        mask = np.logical_and(mask,self._get_observers_mask(allowed_observers))
        return mask

    def get_data_window(self,startdt,enddt,hemisphere,allowed_observers):
        """Return an ordered dictionary of all observation data variables
        which represents the values of each variable for times in
        [startdt,enddt), in about 50 degrees latitude in hemisphere,
        and with RIDs in list allowed_observers (or all observers if
        allowed_observers is None)
        """
        mask = self.get_data_window_mask(startdt,enddt,hemisphere,allowed_observers)

        recordinds = self['recordinds']
        window_recordinds = recordinds[mask]
        window_unique_records = np.unique(window_recordinds)
        if len(window_unique_records) > 1:
            #Logic to merge records should be here.
            #For now just use the first record
            best_record = window_unique_records[0]
            mask = np.logical_and(mask,recordinds==best_record)

        observation_data_window = OrderedDict()
        for varname,vararray in self.items():
            observation_data_window[varname]=vararray[mask]

        data_window_metadata = self._metadata.copy()
        data_window_metadata['window_startdt']=startdt
        data_window_metadata['window_enddt']=enddt
        data_window_metadata['window_allowed_observers']=allowed_observers

        return observation_data_window, data_window_metadata

    # #Merge duplicate values
    # def deduplicate(self,lats,lons):
    #     """Figure out which observations are colocated and return
    #     boolean array which selects only the first one

    #     Parameters
    #     ----------
    #     lats : np.ndarray
    #         Magnetic latitudes of observations
    #     lons : np.ndarray
    #         AMGeO magnetic 'longitudes' (MLT in degrees) of observations

    #     Returns
    #     -------
    #     not_duplicate : np.ndarray(dtype=bool)
    #         Boolean array which selects only the first of any colocated
    #         observations
    #     """
    #     not_duplicate = np.ones_like(lats,dtype=bool)
    #     X,Y = satplottools.latlon2cart(np.abs(lats),lons,'N')
    #     X_I,X_J = np.meshgrid(X,X,indexing='ij')
    #     Y_I,Y_J = np.meshgrid(Y,Y,indexing='ij')

    #     dist = np.sqrt((X_I-X_J)**2.+(Y_I-Y_J)**2.)
    #     print("Min distance: %f" % (np.nanmin(dist[dist>0.].flatten())))

    #     duptup = np.nonzero(np.logical_and(dist<1.,dist>0.))
    #     inddup_i,inddup_j = duptup[0],duptup[1]
    #     low_tri = inddup_j>inddup_i
    #     inddup_i,inddup_j = inddup_i[low_tri],inddup_j[low_tri]
    #     not_duplicate[inddup_j] = False
    #     print("Deduplicated %d values" % (
    #                         np.count_nonzero(np.logical_not(not_duplicate))))

    #     return not_duplicate

    def get_obs_to_basis(self,startdt,enddt,hemisphere,allowed_observers):
        """Returns the forward operator transforming SuperDARN observations
        (either line of sight (LOS) ion drift velocity or
        electric field estimated from cross product of LOS v and
        radial main field"""
        datadict,metadata = self.get_data_window(startdt,enddt,
                                                    hemisphere,
                                                    allowed_observers)

        lats,lons = np.abs(datadict['lats']),datadict['lons']
        H,Hmeta = self._basis_physics_function(lats,lons)

        #Unit vector components in direction of observations (computed
        #in __init__)
        ph = datadict['data_unit_vec_eastward']
        th = datadict['data_unit_vec_equatorward']

        #Number of columns in forward operator is number of basis fcns
        nbasis = H.shape[1]
        ph_arr = np.tile(np.reshape(ph,(-1,1)),(1,nbasis))
        th_arr = np.tile(np.reshape(th,(-1,1)),(1,nbasis))

        H_ph = _component_array_from_3D_array(H,'eastward')
        H_th = _component_array_from_3D_array(H,'equatorward')

        Hlos = ph_arr*H_ph + th_arr*H_th
        return Hlos

    def get_ingest_data(self,startdt,enddt,hemisphere,allowed_observers):
        """Formats the observations in the correct way so that they can be
        ingested into AMGeO

        Whether observations/basis function coefficients returned represent
        line-of-sight velocity or electric field is controlled by the
        ingest_var class attribute

        Parameters
        ----------


        Returns
        -------
        lats : np.ndarray
            Absolute magnetic latitudes of observations
        lons : np.ndarray
            AMGeO magnetic 'longitudes' (MLT in degrees) of observations
        y : np.ndarray
            1D array of line of sight
            velocity  -or- electric field observations
        y_var : np.ndarray
            1D array of uncertainies (variances) in observations
            (i.e. diagonal of observation error covariance matrix)
        obs_to_basis : np.ndarray
            2D array that represents observations in AMGeO basis
            function coefficients
        component : np.ndarray
            1D Array indicating which component
            the observation represents
        """

        datadict,metadata = self.get_data_window(startdt,enddt,hemisphere,allowed_observers)

        lats = datadict['lats']
        lons = datadict['lons']
        y = datadict['data_los']
        yerr = datadict['errs_los']

        obs_to_basis = self.get_obs_to_basis(startdt,enddt,hemisphere,allowed_observers)

        #Construct obs. error covariance matrix ;
        #actually diagonal of C_b / R, representativeness/observation
        #covariance
        npts = len(y)
        nfac = npts**(.25)
        y_var = nfac*yerr**2

        #Multiply errors by 2 as per
        #Cousins et. al. 2014: Mapping with SuperDARN and AMGeO
        #Reasons: Inaccuracy in geolocating SuperDARN observations and
        #effect of nonunitary index of refraction on HF signal
        y_var *= 2

        ymeta = metadata

        return np.abs(lats),lons,y,y_var,obs_to_basis,ymeta

    def plot_vectors(self,ax,startdt,enddt,hemisphere,allowed_observers,
                        prediction=None,scatter=True,**kwargs):
        """
        Plot the line of sight velocity observations at their locations
        on a polar plot

        Parameters
        ----------
        ax : matplotlib.axes
            Axes on which we will plot
        prediction : None or np.ndarray, optional
            Replacement array of line-of-sight velocity values
            Allows, for example, plotting AMGeO predictions at
            observation locations
        scatter : bool, optional
            Switch to draw dots at observation locations
            as well as vectors
        """

        window_outs = self.get_data_window(startdt,enddt,hemisphere,allowed_observers)
        window_data,window_metadata = window_outs

        lats = window_data['lats']
        lons = window_data['lons']
        obs_data = window_data['data_los']
        obs_direction_ph = window_data['data_unit_vec_eastward']
        obs_direction_th = window_data['data_unit_vec_equatorward']
        obs_units = window_metadata['units']

        #not_dup = self.deduplicate(lats,lon
        #lats,lons = lats[not_dup],lons[not_dup]
        #vlos,verr,azm = vlos[not_dup],verr[not_dup],azm[not_dup]

        #elos *= 1000. #V/m -> mV/m

        X,Y = satplottools.latlon2cart(lats,lons,self.hemisphere)

        V_east = obs_data*obs_direction_ph
        V_eq = obs_data*obs_direction_th

        #Calculate arrow directions for vector plot
        theta = lons-90.
        theta[theta>180.]-=360.
        theta[theta<-180.]+=360.
        theta = np.radians(theta)

        eq_hat_x,eq_hat_y = np.cos(theta),np.sin(theta)
        east_hat_x,east_hat_y = -1.*np.sin(theta),np.cos(theta)

        #Convert vectors to cartesian from top-down polar
        V_x = V_east*east_hat_x + V_eq*eq_hat_x
        V_y = V_east*east_hat_y + V_eq*eq_hat_y

        #vel_x = -1*vel_x
        #vel_y = -1*vel_y
        g = np.logical_and(np.logical_not(np.isnan(V_x)),
            np.logical_not(np.isnan(V_y)))

        if 'mask' in kwargs:
            g = np.logical_and(g,kwargs['mask'])

        color = 'black' if 'color' not in kwargs else kwargs['color']

        if scatter:
            if 'scatter_color' not in kwargs:
                kwargs['scatter_color']='black'
            ax.scatter(X[g],Y[g],2,color=kwargs['scatter_color'],alpha=.6)

            #ax.scatter(X[np.logical_and(g,verr>np.abs(vlos))],
            #           Y[np.logical_and(g,verr>np.abs(vlos))],
            #           2,color='r',alpha=.8)


        Vmag = np.sqrt(V_x[g]**2+V_y[g]**2)
        medval = np.nanmean(Vmag)
        low = Vmag < medval
        high = Vmag >= medval

        if 'key_vector_magnitude' in kwargs:
            key_vec_mag = float(kwargs['key_vector_magnitude'])
        elif 'typicalvalue' in window_metadata:
            key_vec_mag = window_metadata['typicalvalue']
        else:
            key_vec_mag = 1000.

        Ql = ax.quiver(X[g][low], Y[g][low], V_x[g][low], V_y[g][low],
            color=color, angles='xy', scale_units='xy', scale=key_vec_mag/10.,
            alpha=.4, headwidth=4., headlength=5.,width=.004)
        Qh = ax.quiver(X[g][high], Y[g][high], V_x[g][high], V_y[g][high],
            color=color, angles='xy', scale_units='xy', scale=key_vec_mag/10.,
            alpha=.8, headwidth=4., headlength=5.,width=.005)

        ax.quiverkey(Qh,.25,0.9,key_vec_mag,'{}{}'.format(key_vec_mag,obs_units))

    def _check_all_h5group_datasets_same_shape(self,h5group):
        """Determine number of points in this record
        and check that all datasets are same length"""
        reference_ds_shape = h5group['mlats'][:].shape
        for dsname in h5group:
            test_ds_shape = h5group[dsname][:].shape
            if  test_ds_shape != reference_ds_shape:
                raise RuntimeError(('Dataset {} '.format(dsname)
                                    +'unexpected shape '
                                    +'{} '.format(test_ds_shape)
                                    +'expected ',
                                    +'{} '.format(reference_ds_shape)))
        return reference_ds_shape

    def _make_line_of_sight_observations_signed(self,vels,eloss,azms):
        """Line of sight observations come in as strictly positive magnitudes
        with angles (azm) in 0-360. This means that our distribution of
        observations will not be remotely gaussian because it cannot have
        negative values. To fix this, we change conventions to angles
        azm in [-90,90] and where azm is < -90 or > 90, we make the line
        of sight magnitude negative
        """
        beta = azms.copy()
        E_los = eloss.copy()
        v_los = vels.copy()

        #Convert azms from 0-360 to -180,180
        too_pos = azms>180
        too_neg = azms<-180.
        beta[too_pos]=azms[too_pos]-360.
        beta[too_neg]=azms[too_neg]+360.

        away_east = np.logical_and(beta>=0.,beta<=90.)
        away_west = np.logical_and(beta<0.,beta>=-90.)
        toward_east = np.logical_and(beta>90.,beta<=180.)
        toward_west = np.logical_and(beta<-90.,beta>-180.)
        away = np.logical_or(away_east,away_west)
        toward = np.logical_or(toward_east,toward_west)

        #Check
        n_away,n_toward = np.count_nonzero(away),np.count_nonzero(toward)
        n_total = len(beta)
        if (n_away+n_toward)!=n_total:
            raise ValueError('N_toward={},N_away={}'.format(n_away,n_toward)
                             +' sum != total points:{}'.format(n_toward))

        #Convert strictly positive line of sight values
        #to positive for away from radar and negative
        #toward radar, so observation distribution is more
        #gaussian
        beta[toward_east]-=180.
        beta[toward_west]+=180.
        E_los[toward]=-1.*eloss[toward]
        v_los[toward]=-1.*vels[toward]

        log.debug(('{}/{} line of sight observations'.format(n_toward,n_total)
                   +' were made negative'
                   +' because they were toward the radar'))

        return v_los,E_los,beta

    def readDayHDF5(self,dt,hemisphere,datadir=None):
        """Read one day and hemisphere of SuperDARN data from an HDF5 file
        prepared by SuperDARNDL

        Parameters
        ----------
        dt : datetime.datetime
            Date to read for, hour minute second fields ignored

        Returns
        -------
        startdts : list
        enddts : list
        mlats : list
        mlons : list
        mltlons : list
        vels : list
        verrs : list
        eloss : list
        eerrs : list
        azms : list
        rids : list
        bigrfs : list
        """
        if datadir is None:
            #datadir = '/tmp'
            datadir = directories.data_dir

        min_of_day_to_dt = lambda minofday: (datetime.datetime(dt.year,
                                                               dt.month,
                                                               dt.day)
                                             +datetime.timedelta(minutes=minofday))

        h5fn = os.path.join(datadir,'SD_grid_%s%s.h5' % (dt.strftime('%Y%m%d'),
                                                         hemisphere))

        if not os.path.exists(h5fn):
            log.notice(('No file {}'.format(h5fn)
                  +'Attempting to download SuperDARN {} '.format(hemisphere)
                  +'hemisphere data for {}...'.format(dt)))
            download_superdarn_data(dt.year,dt.month,dt.day,hemisphere)
        else:
            log.notice('Loading SuperDARN file {}'.format(h5fn))

        recordinds = []
        startdts,enddts = [],[]
        centerdts,centerjds = [],[]
        mlats,mlons,mltlons = [],[],[]
        vels,verrs,eloss,eerrs,azms,rids,bigrfs = [],[],[],[],[],[],[]

        log.info('Reading HDF5 file %s...' % (h5fn))
        with h5py.File(h5fn,'r') as h5f:

            minofdays = []
            for groupnm in h5f:
                minofdays.append(int(groupnm))
            minofdays.sort()

            for i_record,minofday in enumerate(minofdays):
                groupnm = str(minofday)
                group = h5f[groupnm]

                sdt = min_of_day_to_dt(int(group.attrs['start_min']))
                edt = min_of_day_to_dt(int(group.attrs['end_min']))
                ddt = (edt-sdt)
                centerdt = sdt+ddt/2
                centerjd = special_datetime.datetime2jd(centerdt)

                ds_shape = self._check_all_h5group_datasets_same_shape(group)

                startdts.append(np.array([sdt for i in range(ds_shape[0])]))
                centerdts.append(np.array([centerdt for i in range(ds_shape[0])]))
                enddts.append(np.array([edt for i in range(ds_shape[0])]))
                centerjds.append(np.ones(ds_shape)*centerjd)

                recordinds.append(np.ones(ds_shape)*float(i_record))
                mlats.append(group['mlats'][:])
                mlons.append(group['mlons'][:])
                mltlons.append(group['mltlons'][:])
                vels.append(group['vloss'][:])
                verrs.append(group['verrs'][:])
                eloss.append(group['eloss'][:])
                eerrs.append(group['eerrs'][:])
                azms.append(group['azms'][:])
                rids.append(group['rids'][:])
                bigrfs.append(group['bigrfs'][:])

        #Center julian dates (as an array so we can slice with bools)
        recordinds = np.concatenate(recordinds)
        centerdts = np.concatenate(centerdts)
        centerjds = np.concatenate(centerjds)
        startdts = np.concatenate(startdts)
        enddts = np.concatenate(enddts)
        mlats = np.concatenate(mlats)
        mlons = np.concatenate(mlons)
        mltlons = np.concatenate(mltlons)
        vels = np.concatenate(vels)
        verrs = np.concatenate(verrs)
        eloss = np.concatenate(eloss)
        eerrs = np.concatenate(eerrs)
        azms = np.concatenate(azms)
        rids = np.concatenate(rids)
        bigrfs = np.concatenate(bigrfs)

        vels,eloss,azms = self._make_line_of_sight_observations_signed(vels,
                                                                        eloss,
                                                                        azms)

        fmt = lambda dt: dt.strftime('%Y%m%d %H:%M')
        log.info('Read %d SuperDARN Grid records\n spanning %s-%s' % (len(startdts),
                                                                        fmt(startdts[0]),
                                                                        fmt(enddts[-1])))



        return (recordinds,startdts,enddts,centerdts,centerjds,
                            mlats,mlons,mltlons,
                            vels,verrs,eloss,eerrs,
                            azms,rids,bigrfs)
