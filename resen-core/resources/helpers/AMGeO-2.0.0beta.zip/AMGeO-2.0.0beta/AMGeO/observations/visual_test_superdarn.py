#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import shutil,tempfile,datetime,os
import numpy as np
import matplotlib.pyplot as plt
from AMGeO.observations.superdarn import SuperDARN
from AMGeO.observations.test_superdarn import _time_range,_sd_instance
from geospacepy import satplottools

def _figure_axes():
    f = plt.figure(figsize=(12,12))
    axs = [f.add_subplot(2,2,i+1) for i in range(4)]
    for ax in axs:
        satplottools.draw_dialplot(ax)
    return f,axs

if __name__ == '__main__':

    params = []
    for hemisphere in ['N','S']:
        for observation_type in ['iondriftvelocity','electricfield']:
            params.append((hemisphere,observation_type))

    f,axs = _figure_axes()
    for i,(hemisphere,observation_type) in enumerate(params):
        ax = axs[i]

        sd = _sd_instance(hemisphere,observation_type)

        startdt,enddt = _time_range()
        hemisphere = sd.hemisphere
        allowed_observers = 'all'

        sd.plot_vectors(ax,startdt,enddt,hemisphere,allowed_observers)
        dtfmt = lambda dt: dt.strftime('%H:%M:%S')
        ax.set_title(str(sd)+'\n{}-{}'.format(dtfmt(startdt),dtfmt(enddt)))

    plt.tight_layout()
    f.savefig(os.path.expanduser('~/visual_test_superdarn.png'))
