#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import pytest
import shutil,tempfile,datetime
from numpy import testing as nptest
import numpy as np
from AMGeO.observations.superdarn import SuperDARN

def _date():
    return datetime.datetime(2015,3,16)

def _time_range():
    startdt=_date()+datetime.timedelta(hours=3,minutes=0)
    enddt=_date()+datetime.timedelta(hours=3,minutes=5)
    return startdt,enddt

def _sd_instance(hemisphere,observation_type):
    return SuperDARN(_date(),hemisphere,observation_type=observation_type)

@pytest.fixture(scope='module',params=[('N','electricfield'),
                                       ('S','electricfield'),
                                       ('N','iondriftvelocity'),
                                       ('S','iondriftvelocity') ])
def sd_instance(request):
    hemisphere,observation_type = request.param[0],request.param[1]
    return _sd_instance(hemisphere,observation_type)

def test_angle_los_in_minus_90_90(sd_instance):
    angle_los = sd_instance['angle_los']
    n_angles = len(angle_los)
    in_range = np.logical_and(angle_los>=-90.,angle_los<=90.)
    n_in_range = np.count_nonzero(in_range)
    assert n_in_range == n_angles

def test_data_has_negative_values(sd_instance):
    data = sd_instance['data_los']
    assert np.count_nonzero(data<0)>0

def test_data_window_time_range(sd_instance):
    startdt,enddt = _time_range()
    hemisphere = sd_instance.hemisphere
    allowed_observers = 'all'
    data_window,metadata = sd_instance.get_data_window(startdt,enddt,
                                                        hemisphere,
                                                        allowed_observers)

    def intime(dt):
        return dt >= startdt and dt <= enddt

    assert all([intime(dt) for dt in data_window['dts'].tolist()])
