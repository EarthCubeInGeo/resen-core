#Copyright 2020, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import shutil,tempfile,datetime,os
import numpy as np
import matplotlib.pyplot as plt
from AMGeO.observations.ampere import Ampere
from geospacepy import satplottools

def _figure_axes():
    f = plt.figure(figsize=(10,10))
    axNs = [f.add_subplot(2,2,i) for i in [1,2]]
    axSs = [f.add_subplot(2,2,i) for i in [3,4]]
    for axN,axS in zip(axNs,axSs):
        satplottools.draw_dialplot(axN)
        satplottools.draw_dialplot(axS)

    return f,axNs,axSs

def _date():
    return datetime.datetime(2010,5,29)

def _time_range():
    dt = _date()
    centerdt = dt+datetime.timedelta(hours=4,minutes=0)
    window_width = datetime.timedelta(minutes=5)
    return centerdt-window_width/2,centerdt+window_width/2

if __name__ == '__main__':

    downsample=False
    amp = Ampere(_date(),downsample)

    f,axNs,axSs = _figure_axes()
    for axs,hemisphere in zip([axNs,axSs],['N','S']):
        ax_vec,ax_scat = axs

        startdt,enddt = _time_range()
        allowed_observers = 'all'
        obs_args = (startdt,enddt,hemisphere,allowed_observers)

        amp.plot_vectors(ax_vec,*obs_args)

        datadict,metadata = amp.get_data_window(*obs_args)
        X,Y = satplottools.latlt2cart(datadict['lats'],
                                        datadict['lons']/180*12,
                                        hemisphere)

        Bz = datadict['data_fieldaligned']
        mappable = ax_scat.scatter(X,Y,5,Bz,edgecolor='none',
                                    vmin=-1*metadata['typicalvalue']/10.,
                                    vmax=metadata['typicalvalue']/10.,
                                    cmap='bwr')

        f.colorbar(mappable,ax=ax_scat)

    plt.tight_layout()

    dtfmt = lambda dt: dt.strftime('%H:%M:%S')
    f.suptitle(str(amp)+'\n{}-{}'.format(dtfmt(startdt),dtfmt(enddt)))

    dsstr = 'downsampled' if downsample else ''
    f.savefig(os.path.expanduser('~/visual_test_ampere_{}.png'.format(dsstr)))
