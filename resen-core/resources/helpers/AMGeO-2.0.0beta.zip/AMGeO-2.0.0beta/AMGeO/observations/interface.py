#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import numpy as np
import datetime,logbook
from collections import OrderedDict
#Index into 3rd array dimension for each vector component (AMGeO convention)
from AMGeO.basis.interface import _component_array_from_3D_array
from AMGeO.basis.interface import _component_metadata_from_vector_metadata
from AMGeO.datamodel.record import RecordMetadata
from AMGeO.observations.exceptions import NoDataAvailableError

log = logbook.Logger('AMGeO.observations.interface')

class ObservationsBase(object):
    def __init__(self,observations,allowed_observers,component_name=None):
        self.observations = observations
        self.allowed_observers = allowed_observers
        self.component_name = component_name

    @staticmethod
    def _dt_to_startdt_enddt(dt):
        """Here we hard code that we will always want a five minute window.
        This should be the ONLY place this ever appears
        """
        delta_dt = datetime.timedelta(minutes=5)
        startdt = dt-delta_dt/2
        enddt = dt+delta_dt/2
        return startdt,enddt

    def _component_if_3D_arr_or_meta(self,item):
        """
        If the input numpy.ndarray arr is 3D, assume it's a vector
        and try to index it along the 3rd dimension. If it's 1D or 2D,
        just return it because it's not a vector (by convention)
        """
        if isinstance(item,np.ndarray):
            arr = item
            arr_ndims = len(arr.shape)
            if arr_ndims<=2:
                return arr
            else:
                return _component_array_from_3D_array(arr,self.component_name)
        elif isinstance(item,RecordMetadata):
            meta = item
            return _component_metadata_from_vector_metadata(meta,self.component_name)
        else:
            return item

    def _outputs_for_component(self,iterable):
        """Takes an iterable, and makes it into a
        a tuple, converting any 3D np.ndarrays
        (vector quanitites by AMGeO convention)
        into 2D as appropriate for the vector component component_name.
        If component_name is None
        simply returns a tuple version of the input iterable
        """
        if self.component_name is None:
            output_tuple = tuple(item for item in iterable)
        else:
            output_tuple = tuple(self._component_if_3D_arr_or_meta(item)\
                                 for item in iterable)
        return output_tuple

    def get_data_window(self,dt,hemisphere):
        startdt,enddt = self._dt_to_startdt_enddt(dt)
        ins = (startdt,enddt,hemisphere,self.allowed_observers)
        datadict,metadata = self.observations.get_data_window(*ins)
        return datadict,metadata

    def get_ingest_data(self,dt,hemisphere):
        startdt,enddt = self._dt_to_startdt_enddt(dt)
        ins = (startdt,enddt,hemisphere,self.allowed_observers)
        outs = self.observations.get_ingest_data(*ins)
        component_outs = self._outputs_for_component(outs)
        return component_outs

    def plot_vectors(self,ax,dt,hemisphere,**plot_vector_kwargs):
        startdt,enddt = self._dt_to_startdt_enddt(dt)
        ins = (startdt,enddt,hemisphere,self.allowed_observers)
        self.observations.plot_vectors(ax,*ins,**plot_vector_kwargs)

class Observations(ObservationsBase):
    """A class which wraps an Observations class and manages what vector
    component is returned when get_ingest_data is called
    """
    def __init__(self,observations,component_name=None):
        #Basic functionality, but always use all available observers
        ObservationsBase.__init__(self,observations,'all',
                                    component_name=component_name)

class ObserverFilteredObservations(ObservationsBase):
    """A class which wraps an Observations class and only sends back data
    from observers with observer_id in list allowed_observers
    """
    def __init__(self,observations,allowed_observers,component_name=None):
        ObservationsBase.__init__(self,observations,allowed_observers,
                                    component_name=component_name)

class DynamicallyMaskedObservations(ObservationsBase):
    """A class which wraps an Observations class instance and takes a callable
    mask_function, which when called with Observations interface arguments
    (startdt,enddt,hemisphere) and the locations of the observations
    (lats,lons) generates a mask appropriate for that particular window of
    observations.
    """
    def __init__(self,observations,mask_function,component_name=None):
        ObservationsBase.__init__(self,observations,'all',
                                    component_name=component_name)
        self.mask_function = mask_function

    def _get_mask(self,dt,hemisphere):
        data_window,metadata = self.get_data_window(dt,hemisphere)
        lats,lons = data_window['lats'],data_window['lons']
        return self.mask_function(dt,hemisphere,lats,lons)

    # def _mask_output_arrays(self,outs,mask):
    #     masked_outs = []
    #     for out in outs:
    #         if isinstance(out,np.ndarray):
    #             if len(out.shape)==1:
    #                 masked_outs.append(out[mask])
    #             elif len(out.shape)==2:
    #                 masked_outs.append(out[mask,:])
    #                 print(out.shape)
    #             elif len(out.shape)==3:
    #                 masked_outs.append(out[mask,:,:])
    #         else:
    #             masked_outs.append(out)
    #     return tuple(masked_outs)

    def get_ingest_data(self,dt,hemisphere):
        outs = ObservationsBase.get_ingest_data(self,dt,hemisphere)
        mask = self._get_mask(dt,hemisphere)
        return tuple(out[mask,...] if isinstance(out,np.ndarray) else out for out in outs)

class ObservationsCollection(object):
    """A class which wraps multiple observations and loads data
    for a particular time from them.
    This class defines the interface for
    loading data from observation classes (the methods that are called here
    must be identicial in name, inputs, and outputs in all observation
    classes
    """
    def __init__(self):
        self.observations_list = []
        self.frozen = False

    def append(self,observations):
        """Adds the observation class instance observations to the list

        Parameters
        ----------
        observations : Object
            Observations class instance (e.g. observation.supermag.SuperMAG)

        Raises
        ------
        RuntimeError
            If the observations are already in the list
        """
        if self.frozen:
            raise RuntimeError(('Cannot add additional observations to '
                                +'collection after __call__ method has been'
                                +'used'))

        if observations in self.observations_list:
            raise RuntimeError('{}'.format(str(observations))
                                +'is already in the observations collection')

        #Make sure observations instance is wrapped
        if isinstance(observations,ObservationsBase):
            self.observations_list.append(observations)
        else:
            raise RuntimeError(('Only wrapped observations (objects of '
                                +' type ObservationBase) may be added to '
                                +' an ObservationsCollection'))

    def __call__(self,dt,hemisphere):
        """Concatenates all ingested observations and stores them to instance
        variables

        Returns
        -------
        y : np.ndarray
            Observation values
        ylats : np.ndarray
            Observation latitudes
        ylons : np.ndarray
            Observation MLT longitudes
        H : np.ndarray
            Forward operator for observation locations
        Cr : np.ndarray
            Diagonal covariance matrix for observations
            (observation variance along diagonal)
        Cb : np.ndarray
            Prior model error covariance matrix

        """
        self.frozen = True

        y_lat_list,y_lon_list,y_list,y_var_list,H_y_list = [],[],[],[],[]

        for observations in self.observations_list:

            try:
                lats,lons,y,y_var,H_y,ymeta = observations.get_ingest_data(dt,hemisphere)

                if len(y.shape)<=2:

                    y_lat_list.append(lats)
                    y_lon_list.append(lons)

                    #y, observation values and y_var, associated variances
                    #we assume uncorrellated errors between observations
                    y_list.append(y)
                    y_var_list.append(y_var)

                    #H, the basis function coefficients for
                    #each observation location
                    H_y_list.append(H_y)

                else:

                    n_vec_cmpnts = y.shape[2]
                    for i_vec_cmpnt in range(n_vec_cmpnts):
                        y_lat_list.append(lats)
                        y_lon_list.append(lons)
                        y_list.append(np.squeeze(y[:,:,i_vec_cmpnt]))
                        y_var_list.append(np.squeeze(y_var[:,:,i_vec_cmpnt]))
                        H_y_list.append(np.squeeze(H_y[:,:,i_vec_cmpnt]))

            except NoDataAvailableError:
                msg = ('Did not ingest '+str(observations)+
                      +' because get_ingest_data returned no data')
                print(msg)
                log.error(msg)


        if len(y_list)==0:
            all_observation_strs = [str(obs) for obs in self.observations_list]
            collection_contents = ','.join(all_observation_strs)
            raise NoDataAvailableError('No data from {}'.format(collection_contents))

        y = np.concatenate(y_list,axis=0)
        ylats = np.concatenate(y_lat_list,axis=0)
        ylons = np.concatenate(y_lon_list,axis=0)
        H_y = np.concatenate(H_y_list,axis=0)
        Cr = np.diag(np.concatenate(y_var_list,axis=0))

        return ylats,ylons,y,Cr,H_y
