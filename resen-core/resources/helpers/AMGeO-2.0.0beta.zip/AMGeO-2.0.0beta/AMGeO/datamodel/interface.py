#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import numpy as np
from collections import OrderedDict
from AMGeO.datamodel.record import Record

class RecordError(Exception):
    pass

class RecordCollection(object):
    """A record collection provides a getitem/setitem inteface to
    a OrderedDict of records
    """
    def __init__(self):
        self._records = OrderedDict()

    @classmethod
    def from_prediction(cls,prediction):
        pass

    def __getitem__(self,varname):
        return self._records[varname]

    def _add_record(self,recordname,record):
        if not isinstance(record,Record):
            raise RecordError('{} is not a Record'.format(record))
        if recordname in self._records:
            raise RecordError(('Record with name {}'.format(recordname)
                                +' already exists!'))
        self._records[recordname]=record

    def __setitem__(self,recordname,record):
        self._add_record(recordname,record)

    def _to_h5(self,h5group):
        for varname,record in self._records.items():
            record._to_h5(varname,h5group)

    def _from_h5(self,h5group):
        for dataset_or_group in h5group:
            if isinstance(dataset_or_group, h5py.Dataset):
                varname = dataset_or_group
                h5dataset = h5group[varname]
                record=Record()
                record._from_h5(h5dataset)
                self._records[varname]=record
