#Copyright 2020, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import random,datetime,os,pdb
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import h5py

from AMGeO.observations import superdarn
from AMGeO.observations.interface import Observations
from AMGeO.observations.interface import DynamicallyMaskedObservations
from AMGeO.datamodel.record import Record,RecordMetadata
from AMGeO.datamodel.interface import RecordCollection
from AMGeO.update.interface import Validator
from AMGeO.driver_default import DefaultDriver,DefaultResult
from AMGeO.driver_default import add_grid_locations_to_h5


def _validation_superdarn(asim_date,asim_hemi):
    """
    SuperDARN observations are by default assimilated as
    electric field observations
    (line of sight velocity crossed with the vertical component of
    the IGRF field), as is done in the SuperDARN Assimilative Mapping (SAM)
    for calculating residuals, as will be done with this
    instance, we instead use the operators appropriate
    for ion drifts directly, so it is easier to interpret the results
    """
    sd = superdarn.SuperDARN(asim_date,asim_hemi,
                                observation_type='iondriftvelocity')
    return sd

class DefaultDriverWithResiduals(object):
    """Like the default driver, but also calculates residuals (for SuperDARN)
    only at present"""
    def __init__(self,date,hemisphere):
        #Object which produces normal AMGeO results (i.e. on a mlat/mlt grid)
        self.default_driver = DefaultDriver(date,hemisphere)
        #The object which stores and querys one day of gridded velocity data
        self.sd_vlos = _validation_superdarn(date,hemisphere)
        #Object which produces predictions of an observed quantity
        #(e.g. line of sight velocity) at the observation locations
        self.validator = Validator(self.default_driver.solver.solver)
        #self.validator.append(Observations(self.sd_vlos))

    def __call__(self,centerdt):

        #Run AMGeO in the default way and get the usual outputs
        default_outputs = self.default_driver(centerdt)
        #prediction_collection,cond_ped,cond_hall,joule_heat,By,Bz,vsw = default_outputs

        #Additionally, run (using the same default settings)
        #at the observation locations, and get the
        #residuals (observations minus predictions)
        residual_collection = self.validator(centerdt,
                                            self.default_driver.hemisphere,
                                            self.default_driver.obscollection)

        return residual_collection,default_outputs

class DefaultResultWithResiduals(object):
    """Works with DefaultResult to add observation residuals to an HDF5 file"""
    def __init__(self,residual_collection,*default_result_inputs):
        self.default_result = DefaultResult(*default_result_inputs)
        self.residual_collection = residual_collection

    def _residual_to_record_collection(self,residual):
        record_collection = RecordCollection()
        record_collection['observed']=Record(residual['observed'],residual.metadata)
        record_collection['predicted']=Record(residual['predicted'],residual.metadata)

        latmeta = RecordMetadata('lats','Apex Magnetic Latitudes','degrees')
        record_collection['lats']=Record(residual.lats,latmeta)
        lonmeta = RecordMetadata('lons','Apex Magnetic Local Time','degrees')
        record_collection['lons']=Record(residual.lons,lonmeta)
        return record_collection

    def to_h5(self,h5fn):
        #First record the normal output
        self.default_result.to_h5(h5fn)
        #Now add the residuals
        with h5py.File(h5fn,'a') as h5f:
            for residual in self.residual_collection:
                shortname = residual.metadata['shortname']
                root_group_name = self.default_result.name
                sub_group_name = shortname
                if sub_group_name in h5f[root_group_name]:
                    sub_group_name = '_'+shortname  
                h5group = h5f.create_group(root_group_name+'/'+sub_group_name)
                record_collection = self._residual_to_record_collection(residual)
                record_collection._to_h5(h5group)


def polarax_to_localtime(ax):
    """
    Helper function which makes a matplotlib polar plot
    have zero of the azimuithal coordinate at the bottom,
    and have labels for localtimes for the azimuth and
    absolute colatitude for the radial coordinate
    """
    #Rotate the plot so that noon is at the top and midnight
    #is at the bottom, and fix the labels so radial direction
    #is latitude and azimuthal direction is local time in hours
    ax.set_theta_zero_location('S')
    theta_label_values = np.array([0.,3.,6.,9.,12.,15.,18.,21.])*180./12
    theta_labels = ['%d:00' % (int(th/180.*12)) for th in theta_label_values.flatten().tolist()]
    ax.set_thetagrids(theta_label_values,labels=theta_labels)

    r_label_values = 90.-np.array([80.,70.,60.,50.,40.])
    r_labels = [r'$%d^{o}$' % (int(90.-rv)) for rv in r_label_values.flatten().tolist()]
    ax.set_rgrids(r_label_values,labels=r_labels)
    return ax

if __name__ == '__main__':

    #Run using the usual test time
    year,month,day = 2015,3,17
    hour,minute,second = 3,2,30
    hemisphere = 'N'

    datedt = datetime.datetime(year,month,day)

    driver = DefaultDriverWithResiduals(datedt,hemisphere)

    centerdt = datetime.datetime(year,month,day,hour,minute,second)

    #Do the data assimilation on the grid and at the observation locations
    residual_collection,default_outputs = driver(centerdt)

    #Create the object which knows how to dump the default outputs and
    #the observation predictions
    result = DefaultResultWithResiduals(residual_collection,*default_outputs)

    #Dump to a test HDF5 file
    h5fn = os.path.expanduser('~/amgeo_v1_output/test_residual.h5')
    add_grid_locations_to_h5(h5fn)
    result.to_h5(h5fn)

    #Extract the observations and predictions of the observations
    #(residual objects store both the observation values and the predictions)
    sd_vlos_residual = residual_collection['vlos_res']

    #Also extract the raw SuperDARN grid data that was used
    ddt = datetime.timedelta(minutes=2,seconds=30)
    sd_datawindow,sd_metadata = driver.sd_vlos.get_data_window(centerdt-ddt,
                                                                centerdt+ddt,
                                                                hemisphere,
                                                                'all')

    #Make quick and dirty plots of the data
    f = plt.figure(figsize=(12,6))
    ax1 = f.add_subplot(121,projection='polar')
    ax2 = f.add_subplot(122,projection='polar')

    vlos_scatter_kwargs = {'edgecolor':'none',
                            'vmin':-750.,
                            'vmax':750.,
                            'cmap':'RdBu_r'}

    ms = 3 #scatterplot markersize

    #First the predictions
    r = 90.-sd_vlos_residual.lats.flatten()
    th = sd_vlos_residual.lons.flatten()/180.*np.pi
    y = sd_vlos_residual['predicted'].flatten()

    cb1 = ax1.scatter(th,r,ms,y,**vlos_scatter_kwargs)
    f.colorbar(cb1,ax=ax1,label='AMGeO Vlos Prediction')
    polarax_to_localtime(ax1)

    #Now the raw observations
    r = 90.-sd_datawindow['lats']
    th = sd_datawindow['lons']/180.*np.pi
    y = sd_datawindow['data_los']

    cb2 = ax2.scatter(th,r,ms,y,**vlos_scatter_kwargs)
    polarax_to_localtime(ax2)
    f.colorbar(cb2,ax=ax2,label='Actual SuperDARN Vlos')

    f.savefig(os.path.expanduser('~/amgeo_v1_output/test_residual.png'))
