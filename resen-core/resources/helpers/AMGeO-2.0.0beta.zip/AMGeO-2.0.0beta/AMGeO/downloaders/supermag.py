#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import sys, os
import logbook,requests
from AMGeO.files.config import load_config
from AMGeO.files.directories import data_dir
from AMGeO.downloaders.http_utils import url_is_webpage

log = logbook.Logger('AMGeO.downloaders.supermag')

config = load_config()
amgeo_api_key = config['amgeo']['api_key']
supermag_username = config['supermag']['username']

sm_api_url = 'https://amgeo.colorado.edu/supermagdl'

def sm_UserLogin_post(username,api_key,auth=None):
    #Should return 201 created
    endpoint = 'login'
    data = {'username':username,'api_token':api_key}
    response = requests.post(sm_api_url+'/'+endpoint,data=data,auth=auth)
    log.debug(str(response))
    log.debug(str(response.text))
    #Returns as unicode...must deal with it
    #response.encoding='UTF-8'
    return response.json()['access_token']

def sm_GetDayData_post(token,year,month,day,auth=None):
    endpoint = 'process'
    auth_header = {'TokenAuthentication': 'Bearer '+token}
    data={'year':year,'month':month,'day':day}
    response = requests.post(sm_api_url+'/'+endpoint,
                                data=data,
                                headers=auth_header,
                                auth=auth)
    log.debug(str(response))
    log.debug(str(response.text))
    resp_json_data = response.json()
    success_key = 'action_succeeded'
    if success_key not in resp_json_data or not resp_json_data[success_key]:
        errstr = 'SuperMAG data service was unable to retrieve requested data.'
        if 'message' in resp_json_data:
            errstr += ' Server message was {}'.format(resp_json_data['message'])
        log.critical(errstr)
        raise RuntimeError(errstr)

    return resp_json_data['filename']

def sm_download_get(token,src_fn,dest_fn,auth=None):
    protected_api = 'protected'
    endpoint = 'download'
    url = sm_api_url+'/'+protected_api+'/'+endpoint+'/'+src_fn
    # if url_is_webpage(url):
    #     raise RuntimeError('URL %s is a webpage not a file' % (url))
    auth_header = {'TokenAuthentication': 'Bearer '+token}
    response = requests.get(url,allow_redirects=True,headers=auth_header,auth=auth)
    with open(dest_fn,'w') as f:
        try:
            datastr = str(response.content,'utf-8')
        except TypeError:
            datastr = str(response.content)
        f.write(datastr)
    log.notice('SM file downloaded %s->%s' % (src_fn,dest_fn))
    return dest_fn

def download_supermag_data(year,month,day):
    y,m,d = year,month,day
    token = sm_UserLogin_post(supermag_username,amgeo_api_key)
    src_fn = sm_GetDayData_post(token,y,m,d)
    dest_fn = os.path.join(data_dir,'%d%.2d%.2d-supermag.txt' % (y,m,d))
    sm_download_get(token,src_fn,dest_fn)
    return dest_fn

if __name__=='__main__':

    logbook.StreamHandler(sys.stdout).push_application()

    download_supermag_data(2015,3,19)

