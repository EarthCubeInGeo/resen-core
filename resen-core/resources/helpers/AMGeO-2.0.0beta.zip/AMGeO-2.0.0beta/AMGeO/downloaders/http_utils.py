#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import requests

def url_is_webpage(url,auth=None):
    head = requests.head(url,allow_redirects=True,auth=auth)
    headers = head.headers
    content_type = headers.get('content-type')
    is_webpage = 'html' in content_type.lower()
    return is_webpage

