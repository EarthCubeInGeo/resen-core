#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import os,sys
import logbook, requests
from AMGeO.files.config import load_config
from AMGeO.files.directories import data_dir
from AMGeO.downloaders.http_utils import url_is_webpage

log = logbook.Logger('AMGeO.downloaders.superdarn')

config = load_config()
superdarn_username = config['superdarn']['username']
superdarn_password = config['superdarn']['password']
api_key = config['amgeo']['api_key']

sd_api_url = 'https://amgeo.colorado.edu/superdarndl' #HTTPS is *required*

def sd_UserLogin_post(username,password,auth=None):
    endpoint = 'login'
    data = {'username':username,'password':password,'api_token':api_key}
    response = requests.post(sd_api_url+'/'+endpoint,data=data,auth=auth)
    log.debug(str(response))
    log.debug(str(response.text))
    #Returns as unicode...must deal with it
    #response.encoding='UTF-8'
    return response.json()['access_token']

def sd_GetDayData_post(token,year,month,day,hemisphere,auth=None):
    endpoint = 'process'
    #Note that the JWT header is 'TokenAuthorization' not 'Authorization'
    #this is because the SuperDARN server currently is behind
    #HTTP basic authentication (which uses the Authorization header)
    auth_header = {'TokenAuthorization': 'Bearer '+token}
    data={'year':year,'month':month,'day':day,'hemisphere':hemisphere}
    response = requests.post(sd_api_url+'/'+endpoint,
                                data=data,
                                headers=auth_header,
                                auth=auth)
    log.debug(str(response))
    log.debug(str(response.text))

    resp_json_data = response.json()
    success_key = 'action_succeeded'
    if success_key not in resp_json_data or not resp_json_data[success_key]:
        errstr = 'SuperDARN data service was unable to retrieve requested data.'
        if 'message' in resp_json_data:
            errstr += ' Server message was {}'.format(resp_json_data['message'])
        log.critical(errstr)
        raise RuntimeError(errstr)

    return resp_json_data['filename']

def sd_download_get(src_fn,dest_fn,auth=None):
    endpoint = 'download'
    url = sd_api_url+'/'+endpoint+'/'+src_fn
    if url_is_webpage(url,auth=auth):
        raise RuntimeError('URL %s is a webpage not a file' % (url))
    response = requests.get(url,allow_redirects=True,auth=auth)
    with open(dest_fn,'wb') as f:
        f.write(response.content)
    log.notice('SD file downloaded %s->%s' % (src_fn,dest_fn))
    return dest_fn

def download_superdarn_data(year,month,day,hemisphere):
    y,m,d,hemi = year,month,day,hemisphere
    token = sd_UserLogin_post(superdarn_username,superdarn_password)
    src_fn = sd_GetDayData_post(token,y,m,d,hemi)
    dest_fn = os.path.join(data_dir,'SD_grid_%d%.2d%.2d%s.h5' % (y,m,d,hemi))
    sd_download_get(src_fn,dest_fn)
    return dest_fn

if __name__=='__main__':

    logbook.StreamHandler(sys.stdout).push_application()

    download_superdarn_data(2009,3,11,'N')
