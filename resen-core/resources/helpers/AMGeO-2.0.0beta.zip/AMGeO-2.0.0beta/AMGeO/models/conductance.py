#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import numpy as np
import scipy,os,timeit
from collections import OrderedDict

#Library of models (conductance, electric potential, etc.)
import ovationpyme
from ovationpyme import ovation_prime
from geospacepy import special_datetime

from AMGeO.datamodel.record import RecordMetadata

_meta_ped=RecordMetadata('ped','Pedersen Conductance','mho')
_meta_hall=RecordMetadata('hall','Hall Conductance','mho')

class ConstantConductance(object):
    """A default naiive conductance model, i.e.
    constant 4 S conductance everywhere

    Attributes
    ----------
    background_cond_ped : float
        Constant globabl Pedersen conductance in Siemens
    background_cond_hall : float
        Constant global Hall conductance in Siemens
    dt : datetime.datetime
        For consistancy of interface between this
        and the Ovation conductance, there is a time
        setting, but it doesn't do anything
    """
    def __init__(self):
        self.background_cond_ped = 4.
        self.background_cond_hall = 4.
        self.meta_ped = _meta_ped.copy()
        self.meta_hall = _meta_hall.copy()
        self.meta_ped['background']=self.background_cond_ped
        self.meta_hall['background']=self.background_cond_hall

    def __call__(self,dt,hemisphere,mlat_grid,mlon_grid):
        """
        Get Hall and Pedersen conductance at each location

        Parameters
        ----------
        dt : datetime.datetime
            Date and time for model run (usused, here to satisfy model
            __call__ interface standard)
        hemisphere : str,['N' or 'S']
            Hemisphere to run model for (usused, here to satisfy model
            __call__ interface standard)
        mlat_grid : np.ndarray
            Magnetic latitudes
        mlon_grid : np.ndarray
            Magnetic local times (in units of degrees)

        Returns
        -------
        cond_ped_grid : np.ndarray
            Pedersen conductance
        cond_hall_grid : np.ndarray
            Hall conductance

        """
        cond_ped_grid = np.ones_like(mlat_grid)*self.background_cond_ped
        cond_hall_grid = np.ones_like(mlat_grid)*self.background_cond_hall
        return cond_ped_grid,cond_hall_grid


class OvationPymeConductance(object):
    """The Ovation Prime-based conductance model

    Attributes
    ----------
    estimator : ovationpyme.ovation_prime.ConductanceEstimator
        Object that calculates auroral precipitation and estimates
        conductance using Robinson formula
    hemisphere : str,{'N','S'}
        Which hemisphere we want to get Ovation precipitation for
    auroral :  bool
        Calcuate and include auroral contribution to conductance in
        outputs
    solar : bool
        Calculate and include solar contribution to conductance in
        outputs
    background_ped : float
        Constant background pedersen conductance (if auroral and solar
        are both False, this is all you'll get)
    background_hall : float
        Constant background hall conductance (if auroral and solar
        are both False, this is all you'll get)
    fluxtypes : list
        Ovation classes of auroral precipitation to use
        List can contain any of the following:
        'diff' - diffuse aurora
        'mono' - discrete/monoenergetic aurora
        'wave' - broadband auroral precitation
    dt : datetime.datetime
        Time setting for model (when to get auroral preciptation results for)

    Notes
    -----

    Model is intended to replicate protocol in:

    E.D.P Cousins, Tomoko Matsuo, and A.D. Richmond.
    'Mapping High-Latitude Ionospheric Electrodynamics with SuperDARN and AMPERE'
    JGR Space Physics, 2015

    """
    def __init__(self,auroral=True,solar=True):
        """

        Parameters
        ----------
        startdt : datetime.datetime
            The earliest time for which we would expect to get the conductance
        enddt : datetime.datetime
            The latest time for which we would expect to get the conductance
        auroral :  bool,optional
            Calcuate and include auroral contribution to conductance in
            outputs
        solar : bool,optional
            Calculate and include solar contribution to conductance in
            outputs

        """
        self.estimator = ovation_prime.ConductanceEstimator()
        self.auroral=auroral # Switch to turn off auroral conductance
        self.solar=solar # Switch to turn off solar conductance
        # Set a background conductance against which the EUV and auroral conductances will
        # be enhancements (i.e. conductance will never be below the background level)
        # This is from Cousins et. al. 2015 & 2016, in which the AMPERE and SuperDARN
        # datasets were used in AMGeO. They found that a conductance background of 4
        # Siemens produces the mutually lowest error against DMSP and AMPERE
        self.background_ped = 4.
        self.background_hall = 4.
        self.interp_bad_bins = True
        self.fluxtypes = ['diff'] #Choose from diff, mono, wave (aka, diffuse,discrete,broadband)

        self.meta_ped = _meta_ped.copy()
        self.meta_hall = _meta_hall.copy()
        self.meta_ped['background']=self.background_ped
        self.meta_hall['background']=self.background_hall
        for meta in self.meta_hall,self.meta_ped:
            meta['auroral_conductance']=self.auroral
            meta['solar_conductance']=self.solar

    def _check_hemisphere(self,hemisphere):
        if hemisphere not in ['N','S']:
            raise ValueError('Hemisphere is not N or S')

    def __call__(self,dt,hemisphere,mlat_grid,mlon_grid):
        """Get hall and pedersen conductance at each location
        mlat(i),mlon(i) for solar wind conditions for date and time dt

        Parameters
        ----------
        mlat_grid : np.ndarray
            Magnetic latitudes

        mlon_grid : np.ndarray
            AMGeO magnetic 'longitudes' (MLT in degrees)

        Returns
        -------
        cond_ped_grid : np.ndarray
            Pedersen conductance for given locations
        cond_hall_grid : np.ndarray
            Hall conductance for given locations

        Raises
        ------
        ValueError
            If class attribute dt is unset or latitudes have
            negative values and hemi is N
        """

        self._check_hemisphere(hemisphere)

        # I think ovation only takes absolute latitudes
        mlat_grid = np.abs(mlat_grid)
        #??? why is this here
        if hemisphere is 'S':
            mlat_grid *= -1.

        # Convert magnetic 'longtiude' to hours
        mlt_grid = mlon_grid/180.*12.

        #Calculate conductance on default grid
        co = self.estimator.get_conductance(dt,
                                            hemi=hemisphere,
                                            auroral=self.auroral,
                                            solar=self.solar,
                                            background_p=self.background_ped,
                                            background_h=self.background_hall,
                                            conductance_fluxtypes=self.fluxtypes,
                                            interp_bad_bins=self.interp_bad_bins)

        ovation_mlatgrid,ovation_mltgrid,pedgrid,hallgrid = co

        #Create interpolator objects to go between ovation grid and passed grid
        ped_interpolator = ovation_prime.LatLocaltimeInterpolator(
                                                            ovation_mlatgrid,
                                                            ovation_mltgrid,
                                                            pedgrid)
        hall_interpolator = ovation_prime.LatLocaltimeInterpolator(
                                                            ovation_mlatgrid,
                                                            ovation_mltgrid,
                                                            hallgrid)

        cond_ped_grid = ped_interpolator.interpolate(mlat_grid,
                                                    mlt_grid)
        cond_hall_grid = hall_interpolator.interpolate(mlat_grid,
                                                        mlt_grid)

        return cond_ped_grid, cond_hall_grid


