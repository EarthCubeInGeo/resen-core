"""Summary
"""
#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import numpy as np
from logbook import Logger
import scipy,os,timeit

from geospacepy import special_datetime
from nasaomnireader.omnireader import omni_interval_delay_smooth
from geospacepy.satplottools import dipole_tilt_angle
from scipy.special import lpmn
from scipy.special import factorial
import sys,os

from AMGeO.files.directories import tables_dir

log = Logger('AMGeO.models.cs10')

def legendre(n,x,derivative=True,normalization=None):
	"""
	Computes Schmidt Seminormalized Legendre Polynomial values for scalar

	float x:
		P^n_m(x) for orders (m) 0 to n, and degrees (n) 0 to n
		Duplicates matlab function legendre with 'sch' optional argument
		to Schmidt normalize

		Pn(x) for m=0
		Smn(x)=(-1)^m*sqrt(2(n-m)!/(n+m)!)Pmn(x) for m>0

	Args:
		n (TYPE): Description
		x (TYPE): Description
		derivative (bool, optional): Description
		normalization (None, optional): Description

	Returns:
		TYPE: Description

	Raises:
		RuntimeError: Description
	"""

	#Get unnormalized polynomials
	Pnm,dPnm = lpmn(n,n,x)

	#Order m in row, degree n in columns
	M,N = np.meshgrid(np.arange(n+1),np.arange(n+1),indexing='ij')

	if normalization is 'sch':
		norm_factor = (-1.)**M*np.sqrt((2.*factorial(N-M))/factorial(N+M))
		#No normalization needed for m=0.
		norm_factor[0,:] = 1.
	elif normalization is None:
		norm_factor = np.ones_like(Pnm)
	else:
		raise RuntimeError(('Bad normalization %s' % (normalization)
							+' use "sch" for Schmidt'
							+'or None'))

	# To match matlab, must return for degree == n only, i.e. last column?

	if not derivative:
		return (Pnm*norm_factor)[:,-1]
	else:
		return (Pnm*norm_factor)[:,-1],(dPnm*norm_factor)[:,-1]


class cs10coef(object):
	"""Class for representing one CS10 coefficient file
	"""
	def __init__(self,fn,esw_center,cang_center,tilt_center,
						esw_lims,cang_lims,tilt_lims,
						n_coeff=81):
		"""Loads up the coefficient file

		Args:
			fn (str): Full path of file to load
		"""
		if not os.path.exists(fn):
			raise IOError('CS10 Coeffcient file %s does not exist' % (fn))
		self.fn = fn
		self.n_coeff = n_coeff # How many coefficients we expect?
		self.esw_center,self.esw_lims = esw_center,esw_lims
		self.cang_center,self.cang_lims = cang_center,cang_lims
		self.tilt_center,self.tilt_lims = tilt_center,tilt_lims
		data = self._read_data()
		self.latmin = self._read_meta()
		if len(data[:,0])!=self.n_coeff:
			raise ValueError('Expected %d coefficents, got %d' % (n_coeff,
																len(data[:,0])))
		self.ms = data[:,0] #Don't actually know, guessing it's order
		self.ns = data[:,1] #Don't actually know, guessing it's degree
		self.coeffs = data[:,2] # Actually the coefficients
		self.more_coeffs = data[:,3] # Derivatives?

	def __str__(self):
		"""Print out string representation
		"""
		out = (
			"Coefficient file %s" % (self.fn)
			+"E SW: %f (%s)" % (self.esw_center, str(self.esw_lims))
			+"Clock Angle: %f (%s)" % (self.cang_center, str(self.cang_lims))
			+"Dipole Tilt: %f (%s)" % (self.tilt_center, str(self.tilt_lims))
			)
		return out

	def __call__(self):
		"""Return coefficients
		"""
		return self.coeffs

	def _read_meta(self):
		"""Read the file metadata
		#IDL read code
		annot_str  =  ' '
		readf,sph_unit,annot_str
		readf,sph_unit,n_bin,calc_var_flag
		readf,sph_unit,n_cen,xlat_cen,xlon_cen,xrho_cen
		readf,sph_unit,order,dim_1,dim_2,latmin,phi_tot
		readf,sph_unit,latzer,chi_sqr,degfree,rms_err,phi_tot, $
			   chi_sqr_dat,degfree_dat,vmag_max,verr_min, $
			   error_wt_flag,model_wt_flag
		solution   =  fltarr(dim_1,dim_2)
		readf,sph_unit,solution
		"""
		with open(self.fn,'r') as f:
			annot_str = f.readline()
			line2 = [float(s) for s in f.readline().split()]
			n_bin,calc_var_flag = line2
			line3 = [float(s) for s in f.readline().split()]
			n_cen,xlat_cen,xlon_cen,xrho_cen = line3
			line4 = [int(s) for s in f.readline().split()]
			order,dim_1,dim_2,latmin,phi_tot = line4
			line5 = [float(s) for s in f.readline().split()]
			latzer,chi_sqr,degfree,rms_err,phi_tot = line5
			line6 = [float(s) for s in f.readline().split()]
			chi_sqr_dat,degfree_dat,vmag_max = line6[:3]
			verr_min,error_wt_flag,model_wt_flag = line6[3:]
		return latmin

	def _read_data(self):
		"""Read the coefficients
		"""
		return np.genfromtxt(self.fn,skip_header=6)


class CS10(object):
	"""Class for holding Cousins and Shephard 2010 model

	Attributes:
		coeff_path (TYPE): Description
	"""
	def __init__(self,silent=True):
		"""Summary
		"""
		#This switch is to make this CS10 exactly mimic original
		#CS10 in which the highest solar wind electric field bin
		#is not used for IMF Bz south.
		self.ignore_highest_esw_bin_for_Bz_south = True
		self.coeff_path = os.path.join(tables_dir,'cs10')
		self.order = 8 #Order of spherical harmonics
		self.n_coeff = 81 # Number of spherical harmonics coefficients
		self.silent = silent
		self._define_bins()
		self.coeffs = {}
		self.latmins = {}
		self.coeffs['N'],self.latmins['N'] = self._read_coeffs('north')
		self.coeffs['S'],self.latmins['S'] = self._read_coeffs('south')

	def _define_bins(self):
		"""Calculate the bounds of the solar wind condition
		bins that represent the different CS10 coefficient files
		"""

		#Lambda to calculate bin centers from bin edges
		lims = lambda edges: [[bottom,top] for bottom,top in zip(edges[:-1],edges[1:])]
		centers = lambda edges: [(bottom+top)/2 \
									for bottom,top in lims(edges)]

		#Solar Wind Electric Field (Esw) Bins
		self.esw_edges   =  [0, 1.2, 1.7, 2.2, 2.9, 4.1, 20]
		self.esw_lims = lims(self.esw_edges)
		self.esw_centers =  centers(self.esw_edges)
		self.esw_labels = ['%.2ft%.2f' % (bot,top) \
						for bot,top in self.esw_lims]
		self.n_esw = len(self.esw_labels)

		#Not sure why we need this?
		self.esw_centers[-1] = 7.5

		#Clock angle bins
		#Apparently these edges are never actually used?
		self.cang_edges = [-25., 25., 70., 110., 155., 205., 250., 290.,335.]
		self.cang_lims = lims(self.cang_edges)
		self.cang_centers = centers(self.cang_edges)

		self.cang_labels = ['Bz+','Bz+_By+','By+','Bz-_By+','Bz-',
					 'Bz-_By-','By-','Bz+_By-']
		self.n_cang = len(self.cang_labels)

		#Dipole tilt bins
		self.tilt_edges  = [-35.,-10.,10.,35.]
		self.tilt_lims = lims(self.tilt_edges)
		self.tilt_centers = centers(self.tilt_edges)
		#NOTE: For purposes of interpolation the bin center is NOT
		#the value used, these values are -20,0,20
		self.tilt_effective_centers = [-20.,0.,20.]
		self.tilt_labels =  ['_DP-', '_DP0','_DP+']
		self.n_tilt = len(self.tilt_labels)

	def _coeff_file_iterator(self,hemi):
		"""
		Iterator to yield coefficient file names/paths
		Cycles through tilt angles fastest, then clock angles, and
		solar wind electric fields slowest
		"""
		coeffns = []
		for i_esw,esw_label in enumerate(self.esw_labels):
			for i_cang,cang_label in enumerate(self.cang_labels):
				for i_tilt,tilt_label in enumerate(self.tilt_labels):
					coeffn=('omni.'
							+hemi
							+'_'+esw_label
							+'_'+cang_label
							+tilt_label
							+'.bsph')
					fn = os.path.join(self.coeff_path,coeffn)
					yield i_esw,i_cang,i_tilt,fn

	def _read_coeffs(self,hemi):
		"""
		Iterate through all possible conditions and read the coefficient
		files
		"""
		coeffs = np.full((self.n_esw,self.n_cang,self.n_tilt,self.n_coeff),
						np.nan)
		latmins = np.full((self.n_esw,self.n_cang,self.n_tilt),
						np.nan)

		for (i_esw,i_cang,i_tilt,fn) in self._coeff_file_iterator(hemi):
			coefobj = cs10coef(fn,
								self.esw_centers[i_esw],
								self.cang_centers[i_cang],
								self.tilt_effective_centers[i_tilt],
								self.esw_lims[i_esw],
								self.cang_lims[i_cang],
								self.tilt_lims[i_tilt],
								n_coeff=self.n_coeff)
			if not self.silent:
				print(coefobj)
			coeffs[i_esw,i_cang,i_tilt] = coefobj.coeffs
			latmins[i_esw,i_cang,i_tilt] = float(coefobj.latmin)

		log.debug(np.nonzero(np.logical_not(np.isfinite(coeffs))))
		return coeffs,latmins

	def _edge_range(self,x,centers,degrees=False):
		"""
		Search for indices of lower and upper coefficent files
		for interpolation.
		"""
		nbins = len(centers)

		if not degrees:
			lows = centers[:-1]
			highs = centers[1:]
		else:
			if x > 360.:
				x = np.mod(x,360.)
			while x < 0.:
				x += 360.
			lows = centers
			highs = centers[1:]+[centers[0]+360.]

		bigfloat = 9.99e27
		effective_xs = [lows[0]]+[x for i in range(len(lows))]+[highs[-1]]
		x_ranges = [(-1*bigfloat,lows[0])]+[(l,h) for l,h in zip(lows,highs)]+[(highs[-1],bigfloat)]
		x_lims = [(lows[0],highs[0])]+[(l,h) for l,h in zip(lows,highs)]+[(lows[-1],highs[-1])]

		if not degrees:
			#	 Below lowest, between bins, above highest
			x_ilows = [0]+[b for b in range(nbins-1)]+[nbins-2]
			x_ihighs = [1]+[b for b in range(1,nbins)]+[nbins-1]
		else:
			#	 Below lowest, between bins, above highest
			x_ilows = [0]+[b for b in range(nbins-1)]+[nbins-1]
			x_ihighs = [1]+[b for b in range(1,nbins)]+[0] #Wraparound if angle

		i_lim_match = None
		for i_range,(lowbound,highbound) in enumerate(x_ranges):
			if x>=lowbound and x<highbound:
				 i_lim_match = i_range
		if i_lim_match is None:
			raise RuntimeError('Failed to find a matching bin!')
		elif i_lim_match == 0 and not self.silent:
			print('Value %f smaller than first bin %f\n' % (x,x_lims[0][1])
					+' thresholding %f->%f' % (x,effective_xs[i_lim_match]))
		elif i_lim_match == len(x_lims)-1 and not self.silent:
			print('Value %f bigger than last bin %f\n' % (x,x_lims[-1][0])
					+' thresholding %f->%f' % (x,effective_xs[i_lim_match]))

		effective_x = effective_xs[i_lim_match]
		x_lim = x_lims[i_lim_match]
		ilow = x_ilows[i_lim_match]
		ihigh = x_ihighs[i_lim_match]
		return effective_x,x_lim,ilow,ihigh

	def _coeff_indices(self,esw,cang,tilt):
		"""Determine the indicies of
		the coeff objects relevent to the solar wind conditions.
		"""

		esw_out = self._edge_range(esw,self.esw_centers)
		esw_eff,esw_lims,iel,ieh = esw_out

		#Degrees switch allows wraparound (last bin to first) for interp
		cang_out = self._edge_range(cang,self.cang_centers,degrees=True)
		cang_eff,cang_lims,icl,ich = cang_out

		#Not sure on this one...5 degrees or so off the actual bin centers
		tilt_out = self._edge_range(tilt,self.tilt_effective_centers)
		tilt_eff,tilt_lims,itl,ith = tilt_out

		return esw_out,cang_out,tilt_out

	def _top_esw_bin_hack(self,esw_out,cang_out,tilt_out):
		"""
		#Heinous hack to duplicate original CS10 behavior
		#For some reason it doesn't use Bz- bin for top solar wind
		#electric field classification, even though there is a coefficient
		#file for it...go figure
		"""
		esw_eff,esw_lims,iel,ieh = esw_out
		cang_eff,cang_lims,icl,ich = cang_out
		tilt_eff,tilt_lims,itl,ith = tilt_out
		if (iel==self.n_esw-2)\
			and (icl >= 2 and icl < 5) \
			and not (icl==2 and cang_eff==0.):

			if not self.silent:
				print(('Warning:'
					   +' Highest Esw bin and'
					   +' Bz-/Bz-By+/Bz-By- clock angle bin.\n'
					   +' original CS10 code had special case'
					   +' which uses one lower Esw bin for no'
					   +' apparent reason.\n Coefficient file exists'
					   +' for top bin, is it for some reason wrong?'))

			#3.5 is top edge of second to last Esw bin
			esw_eff,esw_lims,iel,ieh = self._edge_range(3.5,self.esw_centers)

		return esw_eff,esw_lims,iel,ieh

	def _trilinear_interpolate(self,hemi,esw,cang,tilt):
		"""
		Obtain exact coefficients for
		solar wind conditions between bins
		using trilinear interpolation
		(built from IDL code)
		"""

		#NaN filter
		if not np.isfinite(esw):
			log.debug("CS10: Non-finite Solar Wind Electric Field, setting to zero")
			esw = 0.
		if not np.isfinite(cang):
			log.debug("CS10: Non-finite Solar Wind Clock Angle, setting to zero")
			cang = 0.
		if not np.isfinite(tilt):
			log.debug("CS10: Non-finite Tilt Angle, setting to zero")
			tilt = 0.

		if hemi=='S':
			tilt*=-1.

		if cang<0:
			cang+=360.
		if cang>360.:
			cang = np.mod(cang,360.)

		esw_out,cang_out,tilt_out = self._coeff_indices(esw,cang,tilt)

		if self.ignore_highest_esw_bin_for_Bz_south:
			esw_out = self._top_esw_bin_hack(esw_out,cang_out,tilt_out)

		esw_eff,esw_lims,iel,ieh = esw_out
		cang_eff,cang_lims,icl,ich = cang_out
		tilt_eff,tilt_lims,itl,ith = tilt_out

		dtor = np.pi/180.
		cafac_h = np.abs(np.sin(cang_lims[1]*dtor/2.))
		cafac_l = np.abs(np.sin(cang_lims[0]*dtor/2.))
		cafac   = np.abs(np.sin(cang_eff*dtor/2.))

		denom = (cafac_h-cafac_l)*\
				(esw_lims[1]-esw_lims[0])*\
				(tilt_lims[1]-tilt_lims[0])

		if not self.silent:
			print('Esw:%f ClAng:%f DplTilt: %f' % (esw,cang,tilt))
			print('Esw(Eff):%f ClAng(Eff):%f DplTilt(Eff): %f' % (esw_eff,
																	cang_eff,
																	tilt_eff))
			print('Solar Wind E-field bins %d,%d (%f,%f)' % (iel,ieh,
															esw_lims[0],
															esw_lims[1]))
			print('Clock angle bins %d,%d (%f,%f)' % (icl,ich,
													   cang_lims[0],
													   cang_lims[1]))
			print('Dipolt tilt bins %d,%d (%f,%f)' % (itl,ith,
												tilt_lims[0],
												tilt_lims[1]))
			print('Sin(ClAng/2) %f,%f,%f' % (cafac_l,cafac,cafac_h))
			print('Denominator: %f' % (denom))

		edge_coeffs,edge_latmins = [],[]
		for ie in (iel,ieh):
			for ic in (icl,ich):
				for it in (itl,ith):
					edge_coeffs.append(np.squeeze(self.coeffs[hemi][ie,ic,it,:]))
					edge_latmins.append(self.latmins[hemi][ie,ic,it])

		interp_coeffs = np.zeros_like(edge_coeffs[0])
		latmin = 0.
		k=0
		for esw_fac in (esw_lims[1]-esw_eff,esw_eff-esw_lims[0]):
			for cang_fac in (cafac_h-cafac,cafac-cafac_l):
				for tilt_fac in (tilt_lims[1]-tilt_eff,tilt_eff-tilt_lims[0]):
					weight = esw_fac*cang_fac*tilt_fac/denom
					interp_coeffs+=edge_coeffs[k]*weight
					latmin+=edge_latmins[k]*weight
					k+=1
		"""
		IDL code
		A = reform(solns[it,im,  ia, *]/denom)
		B = reform(solns[it,im,  ia2,*]/denom)
		C = reform(solns[it,im+1,ia, *]/denom)
		D = reform(solns[it,im+1,ia2,*]/denom)
		E = reform(solns[it+1,im,  ia, *]/denom)
		F = reform(solns[it+1,im,  ia2,*]/denom)
		G = reform(solns[it+1,im+1,ia, *]/denom)
		H = reform(solns[it+1,im+1,ia2,*]/denom)

		coeffs = A*(afac_h-afac)*(mhgh[im]-mag)*(thgh[it]-tilt) $
				 + B*(afac-afac_l)*(mhgh[im]-mag)*(thgh[it]-tilt) $
				 + C*(afac_h-afac)*(mag-mlow[im])*(thgh[it]-tilt) $
				 + D*(afac-afac_l)*(mag-mlow[im])*(thgh[it]-tilt) $
				 + E*(afac_h-afac)*(mhgh[im]-mag)*(tilt-tlow[it]) $
				 + F*(afac-afac_l)*(mhgh[im]-mag)*(tilt-tlow[it]) $
				 + G*(afac_h-afac)*(mag-mlow[im])*(tilt-tlow[it]) $
				 + H*(afac-afac_l)*(mag-mlow[im])*(tilt-tlow[it])

		#Interpolate HMB lat also
		A = float(latmin_arr[it,im,  ia])/denom
		B = float(latmin_arr[it,im,  ia2])/denom
		C = float(latmin_arr[it,im+1,ia])/denom
		D = float(latmin_arr[it,im+1,ia2])/denom
		E = float(latmin_arr[it+1,im,  ia])/denom
		F = float(latmin_arr[it+1,im,  ia2])/denom
		G = float(latmin_arr[it+1,im+1,ia])/denom
		H = float(latmin_arr[it+1,im+1,ia2])/denom

		latmin = A*(afac_h-afac)*(mhgh[im]-mag)*(thgh[it]-tilt) $
				 + B*(afac-afac_l)*(mhgh[im]-mag)*(thgh[it]-tilt) $
				 + C*(afac_h-afac)*(mag-mlow[im])*(thgh[it]-tilt) $
				 + D*(afac-afac_l)*(mag-mlow[im])*(thgh[it]-tilt) $
				 + E*(afac_h-afac)*(mhgh[im]-mag)*(tilt-tlow[it]) $
				 + F*(afac-afac_l)*(mhgh[im]-mag)*(tilt-tlow[it]) $
				 + G*(afac_h-afac)*(mag-mlow[im])*(tilt-tlow[it]) $
				 + H*(afac-afac_l)*(mag-mlow[im])*(tilt-tlow[it])
		"""

		return interp_coeffs,latmin


	def _legendre_index(self,L,m):
		"""
		Convert l,m index of legendre polynomials to flat indexing
		used in coefficient files
		"""
		if m==0:
			return L**2
		elif m!=0 and L!=0:
			return L**2+2*m-1
		else:
			return 0

	def _latlon2thetaphi(self,lats,lons,normalize_theta_to=None):
		"""

		"""
		theta = np.radians(90.-np.abs(lats))
		phi = np.radians(lons)
		if normalize_theta_to is not None:
			theta_norm = theta*(np.pi/np.abs(normalize_theta_to))
			return theta,phi,theta_norm
		else:
			return theta,phi


	def _spherical_harmonics(self,lats,lons,latmin=None):
		"""Get the values of the spherical harmonics (order==self.order)
		for a grid of latitudes and longitudes
		"""
		theta_lim = np.radians(90.-np.abs(latmin))
		thetas,phis,thetas_norm = self._latlon2thetaphi(lats,lons,
										normalize_theta_to=theta_lim)

		#from scipy.special
		legendres = []
		for th in thetas_norm:
			Plm,dPlm = lpmn(self.order,self.order,np.cos(th))
			legendres.append(Plm)
		#degree along rows, order along columns, latitude along last dim
		Plm = np.dstack(legendres)

		#n_coeff should be order+1**2
		sh = np.full((len(lons),self.n_coeff),np.nan)
		for m in range(self.order+1):
			for L in range(m,self.order+1):
				k = self._legendre_index(L,m)
				if m == 0:
					sh[:,k] = Plm[m,L,:]
				else:
					sh[:,k] = np.cos(m*phis)*Plm[m,L,:]
					sh[:,k+1] = np.sin(m*phis)*Plm[m,L,:]


		#Zero out spherical harmonics for any latuitudes below latmin
		out_of_theta_range = thetas.flatten()>theta_lim
		sh[out_of_theta_range,:] = 0.

		return sh

	def __call__(self,lats,lons,hemi,esw,cang,tilt):
		"""
		Calculate CS10 potential
		"""
		interp_coeffs,latmin = self._trilinear_interpolate(hemi,esw,cang,tilt)
		sh = self._spherical_harmonics(lats,lons,latmin=latmin)
		return np.dot(sh,interp_coeffs)

class cs10_driver(object):
	def __init__(self,startdt,enddt,delay_mins=10,avg_mins=45):
		"""
		Container for solar wind / dipole tilt data for CS10
		"""
		self.oi = omni_interval_delay_smooth(startdt,enddt,'1min',
													delay_mins=delay_mins,
													avg_mins=avg_mins)
		self.jds = self.oi.jds
		self.dts = self.oi.dts
		#From geospacepy.satplottools, use empirical formula
		#Approximation from:
		#M. Nowada, J.-H. Shue, C.T. Russell, Effects of dipole
		#tilt angle on geomagnetic activity,
		#Planetary and Space Science, Volume 57, Issue 11,
		#September 2009, Pages 1254-1259,
		#ISSN 0032-0633, http://dx.doi.org/10.1016/j.pss.2009.04.007.
		self.tilt = dipole_tilt_angle(self.dts)
		self.vsw = -1.*self.oi['Vx']
		#self.flow_speed = self.oi['flow_speed']
		self.By = self.oi['BY_GSM']
		self.Bz = self.oi['BZ_GSM']
		self.Bt = np.sqrt(self.By**2+self.Bz**2)
		self.cang = np.degrees(np.arctan2(self.By,self.Bz))
		self.Esw = self.Bt*self.vsw*1.0e-3
		self.dt = None #For stateful access

	def _closest_finite(self,dt,y,back_max=10):
		"""
		Returns closest finite value of y up to back_max
		indices before index ind
		"""
		jd = special_datetime.datetime2jd(dt)
		i_closest = np.nanargmin(np.abs(self.jds-jd))
		this_i = i_closest
		while not np.isfinite(y[this_i]) and i_closest-this_i<=back_max:
			if this_i<0:
				break
			this_i-=1
		if this_i<0 or not np.isfinite(y[this_i]):
			log.warning(('Warning Unable to find non-NaN solar wind value'
					+'within %d of %s, returning zero' % (back_max,str(dt))))
			this_y = 0.
			this_i = i_closest
		else:
			this_y = y[this_i]
		return this_i,this_y

	def get_conditions(self,dt):
		"""
		Get all IMF conditions
		"""
		ivsw,vsw = self._closest_finite(dt,self.vsw)
		iBy,By = self._closest_finite(dt,self.By)
		iBz,Bz = self._closest_finite(dt,self.Bz)
		iesw,esw = self._closest_finite(dt,self.Esw)
		icang,cang = self._closest_finite(dt,self.cang)
		itilt,tilt = self._closest_finite(dt,self.tilt)
		omind = np.nanmedian(np.array([ivsw,iBy,iBz,iesw,icang,itilt]))
		return omind,vsw,By,Bz,esw,cang,tilt

	def __call__(self,dt):
		"""
		Find the closest non-NaN value of each of the drivers
		to a particular datetime
		"""
		iesw,esw = self._closest_finite(dt,self.Esw)
		icang,cang = self._closest_finite(dt,self.cang)
		itilt,tilt = self._closest_finite(dt,self.tilt)
		return esw,cang,tilt
