#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import pytest
import numpy as np
from numpy import testing as nptest
from AMGeO.models import interface

if __name__ == "__main__":
    #Run the tests
    pytest.main()
