import pytest
import numpy as np
import os
import datetime
from numpy import testing as nptest

from AMGeO.files.directories import tables_dir

from AMGeO.basis import physics
from AMGeO.basis import interface
from AMGeO.basis.functions import basis_functions_set as basisset
from AMGeO.basis.grid import grid

class FakeConductanceModel(object):
    def __init__(self):
        pass

    def __call__(self,dt,hemisphere,lats,lons):
        ped = np.ones_like(lats)*2.
        hall = np.ones_like(lons)*4.
        return ped,hall

def _manual_ground_magnetic_perturbation_calculation(dt,hemisphere,lats,lons):
    cond_model = FakeConductanceModel()
    #Full grid (latitudes below transfer latitude)
    full_lat_grid,full_lon_grid = np.meshgrid(basisset.abslats,basisset.lons,
                                                indexing='ij')
    #Calculate "conductance"
    ped,hall = cond_model(dt,hemisphere,full_lat_grid,full_lon_grid)
    #Calculate basis functions for ground magnetic perturbations

    H,Hmeta = physics.get_ground_magnetic_perturbations(lats,lons,ped,hall)
    return H,Hmeta

def test_model_dependant_basis_physics_function_works():
    cond_model = FakeConductanceModel()
    out = interface.ModelDependantBasisPhysicsFunction(cond_model,
                                                        physics.get_ground_magnetic_perturbations)

    conductance_basis_physics_function = out

    dt = datetime.datetime(2000,1,1,12)

    lats,lons = grid.lat_grid.flatten(),grid.lon_grid.flatten()
    basis_physics_function_args = (dt,'N',lats,lons)

    manual_outs = _manual_ground_magnetic_perturbation_calculation(*basis_physics_function_args)
    H_manual,H_manual_meta = manual_outs

    interface_outs = conductance_basis_physics_function(*basis_physics_function_args)
    H_interface,H_interface_meta = interface_outs

    nptest.assert_allclose(H_manual,H_interface)
    assert(H_manual_meta==H_interface_meta)

if __name__ == "__main__":
    #Run the tests
    pytest.main()
