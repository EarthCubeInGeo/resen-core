import pytest
import os
import numpy as np
from AMGeO.files.directories import tables_dir
from AMGeO.basis.eofs import (CuKp3PrincipalComponents,
                              AMGeOBasisFunctions,
                              EmpiricalOrthogonalFunctionSet)
    
def load_amgeo_eofs(n_eofs,truncate):
    amgeo_eof_h5fn = os.path.join(tables_dir,
                        'eofs',
                        'EOFAmperesNstart2015031700end2015031723deltat0:10:00.h5')
    eof_basis = CuKp3PrincipalComponents()
    eofs = EmpiricalOrthogonalFunctionSet(n_eofs,eof_basis,truncate=truncate)
    eofs.load_amgeo_eof_h5(amgeo_eof_h5fn)
    return eofs

@pytest.mark.parametrize('n_eofs,truncate',[(6,False),(4,True)])
def test_can_load_amgeo_eof_h5(n_eofs,truncate):
    eofs = load_amgeo_eofs(n_eofs,truncate)
    assert eofs['betas'].shape[1]==n_eofs

def test_raises_ValueError_on_bad_n_eofs_without_truncate():
    with pytest.raises(ValueError):
        load_amgeo_eofs(4,False)

@pytest.mark.parametrize('eof_kind',['all','cme','hss','slw'])
def test_can_load_shi20(eof_kind):
    betasfn = os.path.join(tables_dir,'shi20',eof_kind,'beta_all_north.dat')
    eof_basis = AMGeOBasisFunctions()
    n_eofs = 30
    eofs = EmpiricalOrthogonalFunctionSet(n_eofs,eof_basis,truncate=False)
    eofs['betas'] = np.genfromtxt(betasfn)
    assert eofs['betas'].shape[1]==n_eofs

