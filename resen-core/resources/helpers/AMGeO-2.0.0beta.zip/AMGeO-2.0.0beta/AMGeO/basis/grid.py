#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import numpy as np
from AMGeO.basis.functions import basis_functions_set as basisset

class GridError(Exception):
    pass

class Grid(object):
    """This defines the latitudes and longitudes of the AMGeO grid.
    This is *the* grid for AMGeO because it's the grid for which we have
    pre-calculated basis function values (loaded in basis.functions module).
    The BasisFunctionSet object (from basis.functions) has methods to
    interpolate the tabulated basis function values to other grids
    (otherwise it wouldn't be possible to get the basis function values for
    observations, for example), but this is the 'natural' grid, and is the
    grid for which all AMGeO results are calculated
    """
    def __init__(self):
        self.lats = basisset.abslats[:basisset.qmeta['ithtrns']]
        self.lons = basisset.lons
        self.lat_grid,self.lon_grid = np.meshgrid(self.lats,self.lons,indexing='ij')

    def azi_difference(self,azi1,azi2,lonorlt='lon',radians=True):
        """Difference between two longitudes or local times (azi2-azi1),
            taking into account wrapping"""
        azi2rad = np.pi/12. if lonorlt=='lt' else np.pi/180.
        d_azi = np.arctan2(np.sin(azi2*azi2rad-azi1*azi2rad),
                            np.cos(azi2*azi2rad-azi1*azi2rad))
        if not radians:
            d_azi = d_azi/azi2rad
        return d_azi

    def grid_cell_area(self,celldims,r_m=(6371.2+110.)*1000.):
        """
        Simply returns the bin surface area in m,
        assuming that the bin is a spherical
        rectangle on a sphere of radius r_m meters

        INPUTS
        ------
            celldims - [lat_start,lat_end,lon_start,lon_end]

            r_m - float, optional
                The radius of the sphere, in meters, defaults
                to Re+110km, i.e. the height of the ionosphere

        RETURNS
        -------
            A - float
                The surface area of the patch in m**2

        """
        theta2 = (90.-celldims[0])*np.pi/180. #theta / lat - converted to radians
        theta1 = (90.-celldims[1])*np.pi/180. #theta / lat - converted to radians

        dphi = self.azi_difference(celldims[2],celldims[3],radians=True)
        return np.abs(r_m**2*dphi*(np.cos(theta1)-np.cos(theta2)))

    def reshape_to_grid(self,arr):
        """Reshapes a numpy array to the shape of the grid"""
        return arr.reshape(self.lat_grid.shape)

    def grid_integrate(self,y):
        """
        Integrates a variable defined for a grid of latitudes and longitudes
        assuming that the latitudes and longitudes represents points on the
        surface of a sphere of radius R_e+h_i where h_i is the altitude of the
        ionosphere, by default 110 km, and R_e is the earth radius, by default
        6371.2 km.

        Assumes:
        Latitudes vary along axis 0 (grid_lats[0,0] != grid_lats[1,0])
        Longitudes vary along axis 1 (grid_lats[0,0] != grid_lats[0,1])
        """
        #Check that variable to integrate has same shape as grid
        if y.shape != self.lat_grid.shape:
            grid_y = y.reshape(self.lat_grid.shape)
        else:
            grid_y = y

        # #Check assumtion about latitude and longitude dimensions
        # if not np.array_equal(grid_lats[:,0],grid_lats[:,1]):
        #     raise ValueError('Latitudes not equal along grid rows')
        # if not np.array_equal(grid_lons[0,:],grid_lons[1,:]):
        #     raise ValueError('Longitudes not equal along grid columns')

        lats,lons = self.lat_grid[:,0].flatten(),self.lon_grid[0,:].flatten()

        #Create spherical rectangles for each grid point
        grid_cells = []
        cell_areas = []
        cell_ys = []
        for ilat,(lat1,lat2) in enumerate(zip(lats[:-1],lats[1:])):
            for ilon,(lon1,lon2) in enumerate(zip(lons[:-1],lons[1:])):
                cell = [lat1,lat2,lon1,lon2]
                #dlat = lat2-lat1 #No wraparound problem
                #dlon = azi_difference(lon1,lon2,
                #                       lonorlt='lon',
                #                       radians='False')
                #cell_centers.append([lat1+dlat/2,lon1+dlon/2])
                cell_areas.append(self.grid_cell_area(cell))
                cell_ys.append(np.nanmean(
                                np.array(
                                    [grid_y[ilat,ilon],
                                    grid_y[ilat+1,ilon],
                                    grid_y[ilat,ilon+1],
                                    grid_y[ilat+1,ilon+1]
                                    ])))

        integrated_y = 0.
        for area,y in zip(cell_areas,cell_ys):
            integrated_y+=area*y

        return integrated_y

#-----------------------------------------------------------------------
grid = Grid()
