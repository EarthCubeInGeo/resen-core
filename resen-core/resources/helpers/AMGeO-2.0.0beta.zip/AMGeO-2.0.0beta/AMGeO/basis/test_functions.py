#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import pytest
import numpy as np
import os
from numpy import testing as nptest
from AMGeO.basis import functions

basisset = functions.BasisFunctionsSet()

def test_compute_f_same_as_just_sam_fcmp():
    """
    Does the amgeo_basis azimuthal part of AMGeO functions
    code return the same values for f_m as just_sam.basis._fcmp?
    """
    expected_first_f_column = np.array([ -7.07106781e-01,   4.83689525e-01,  -2.45575608e-01,
         4.27435864e-15,   2.45575608e-01,  -4.83689525e-01,
         7.07106781e-01,  -9.09038955e-01,   1.08335044e+00,
        -1.22474487e+00,   1.32892605e+00,  -1.39272848e+00,
         1.00000000e+00,  -2.45575608e-01,   4.83689525e-01,
        -7.07106781e-01,   9.09038955e-01,  -1.08335044e+00,
         1.22474487e+00,  -1.32892605e+00,   1.39272848e+00,
        -1.41421356e+00,   1.39272848e+00,  -1.32892605e+00,
         1.22474487e+00])

    lons = np.linspace(-170.,170.,30)

    f = basisset.compute_f(lons,mmx=12)

    nptest.assert_allclose(f[:,0],expected_first_f_column,atol=1e-14)

def test_regress_returns_like_matlab():
    """
    Does the amgeo_core helper method regress return the
    same output as the equivalent MATLAB command
    """
    #Tested using MATLAB regress
    expected_coefs = np.array([[.95,.05]])
    X = np.array([[0,0],[0,2],[1,1]])
    y = np.array([0,.1,1])
    coefs = functions.regress(X,y)
    nptest.assert_allclose(coefs,expected_coefs,atol=1e-14)

if __name__ == "__main__":
    #Run the tests
    pytest.main()
