#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
from AMGeO.files import (config,directories)
from AMGeO.files.directories import (config_dir,assets_dir,tables_dir,data_dir)

