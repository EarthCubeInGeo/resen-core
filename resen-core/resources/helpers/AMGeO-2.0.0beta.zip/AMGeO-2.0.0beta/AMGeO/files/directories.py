#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import pkg_resources,os

#Determine where this module's source file is located
src_file_dir = os.path.dirname(os.path.realpath(__file__))

try:
    config_dir = pkg_resources.resource_filename('AMGeO.files','config')
    tables_dir = pkg_resources.resource_filename('AMGeO.files','tables')
    assets_dir = pkg_resources.resource_filename('AMGeO.files','assets')
except ImportError:
    print('Warning: AMGeO does not appear to be installed.')

    config_dir = os.path.join(src_file_dir,'config')
    tables_dir = os.path.join(src_file_dir,'tables')
    assets_dir = os.path.join(src_file_dir,'assets')

appdirs = pkg_resources.appdirs.AppDirs('AMGeO','AMGeO Collaboration')
data_dir = appdirs.user_data_dir #~/.local/share/AMGeO on Ubuntu

for potentially_empty_dir in [data_dir,config_dir]:
    if not os.path.exists(potentially_empty_dir):
        os.makedirs(potentially_empty_dir)
