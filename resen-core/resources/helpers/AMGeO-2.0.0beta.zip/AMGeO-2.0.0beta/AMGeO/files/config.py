#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import json, os
from collections import OrderedDict
from pkg_resources import Requirement,resource_filename
from AMGeO.files.directories import config_dir

config_file = os.path.join(config_dir,'amgeo_user.json')

def load_config():
	load_kwargs = {'object_pairs_hook':OrderedDict} #Preserve order from file
	with open(config_file,'r') as f:
		config = json.load(f,**load_kwargs)
	return config

def save_config(config):
	dump_kwargs = {'indent':2} #Keep the file readable after modifying
	with open(config_file,'w') as f:
		json.dump(config,f,**dump_kwargs)
