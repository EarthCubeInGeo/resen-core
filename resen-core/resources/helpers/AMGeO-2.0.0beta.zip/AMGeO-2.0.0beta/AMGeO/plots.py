#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.gridspec as gridspec
import matplotlib.image as mplimg
import datetime,os,traceback
import numpy as np

from geospacepy import satplottools

from AMGeO.basis.grid import grid
from AMGeO.files.directories import assets_dir

# def logo(f):
#     logopng = '/home/liamk/mirror/Projects/amiepy_paper/logo_big.png'
#     splot.add_logo(logopng,f,pos='tr')

def _latlon2cart(lats,lons):
    """Transform absolute latitudes and 'longitudes' (MLT in degrees),
    into cartesian with origin at the pole"""

    if np.any(lats<0):
        raise ValueError(('This function expects only positive'
                          +'(absolute) latitudes'))
    #Calculate cartesian
    X_flat,Y_flat = satplottools.latlon2cart(lats.flatten(),
                                                lons.flatten(),
                                                'N')
    X = X_flat.reshape(lats.shape)
    Y = Y_flat.reshape(lats.shape)
    return X,Y

def _grid_data_for_plot(grid_data):
    lat_grid = grid.lat_grid
    lon_grid = grid.lon_grid

    #will raise exception here if data isn't on grid
    plot_data = grid.reshape_to_grid(grid_data)

    if np.nanmax(lat_grid)<89.9:
        #Add in a extra row for 90 degrees latitude
        #(so no hole in center of plot)
        plot_lat = np.row_stack((np.ones_like(lat_grid[0,:])*89.9,
                                    lat_grid))
        plot_lon = np.row_stack((lon_grid[0,:],lon_grid))

        #Add new first row for 90 degrees latitude
        ninety_lat_row = np.ones_like(plot_data[0,:])*np.nanmedian(plot_data[0,:])
        plot_data = np.row_stack((ninety_lat_row,plot_data))

    X,Y = _latlon2cart(plot_lat,plot_lon)

    return X,Y,plot_data

def _grid_prediction_for_plot(prediction_collection,varname):
    grid_data = prediction_collection[varname]['predicted']
    meta = prediction_collection[varname].metadata
    if varname=='epot':
        if meta['units']!='V':
            raise ValueError('Unexpected epot units {}'.format(meta['units']))
        else:
            grid_data /= 1000.

    X,Y,plot_data = _grid_data_for_plot(grid_data)
    return X,Y,plot_data

def _cart_grid_contourf(ax,X,Y,var,*args,**kwargs):
    if all([kwarg in kwargs for kwarg in ['vmin','vmax','cmap']]):
        norm = mpl.colors.Normalize(vmin=kwargs['vmin'],
                                    vmax=kwargs['vmax'],
                                    clip=True)
        mappable = mpl.cm.ScalarMappable(norm=norm,cmap=kwargs['cmap'])
        mappable.set_array(var)
        levels = np.linspace(kwargs['vmin'],kwargs['vmax'],20)
        level_min = np.nanmin(var)-1 if kwargs['vmin']>(np.nanmin(var)-1) \
                                                        else kwargs['vmin']-1
        level_max = np.nanmax(var)+1 if kwargs['vmax']<(np.nanmax(var)+1) \
                                                        else kwargs['vmax']+1
        levels = np.concatenate( [np.array([level_min]),
                                levels,
                                 np.array([level_max])] )
        forbidden = ['vmin','vmax']
        new_kwargs = {kwarg:kwargs[kwarg] for kwarg in kwargs if kwarg not in forbidden}
        new_kwargs['norm']=norm
        new_kwargs['levels']=levels
        ax.contourf(X,Y,var,*args,**new_kwargs)
        #draw_min_max(ax,var)
        return mappable
    else:
        #draw_min_max(ax,var)
        return ax.contourf(X,Y,var,*args,**kwargs)

def _observations_vector_plot(ax,X,Y,vX,vY,*args,**kwargs):
    pass

def draw_min_max(ax,x):
    ax.text(-40.,-50,
    'Min: %.1f \nMax: %.1f' % (np.nanmin(x.flatten()),
                            np.nanmax(x.flatten())))

def prediction_contourf(ax,prediction_collection,varname,*args,**kwargs):
    X,Y,plot_data = _grid_prediction_for_plot(prediction_collection,varname)
    return _cart_grid_contourf(ax,X,Y,plot_data,*args,**kwargs)

def grid_data_contourf(ax,grid_data,*args,**kwargs):
    X,Y,plot_data = _grid_data_for_plot(grid_data)
    return _cart_grid_contourf(ax,X,Y,plot_data,*args,**kwargs)
