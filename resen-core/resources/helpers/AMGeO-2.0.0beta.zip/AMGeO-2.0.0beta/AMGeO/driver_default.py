#Copyright 2020, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration

import datetime, os, bisect, sys
from collections import OrderedDict
import numpy as np
import matplotlib.pyplot as plt
import logbook
import h5py

from geospacepy import special_datetime
from nasaomnireader.omnireader import omni_interval

from AMGeO.files.directories import tables_dir, data_dir
from AMGeO.basis.grid import grid
from AMGeO.models.electric_potential import CS10ElectricPotential
from AMGeO.models.shi20 import Shi20EOFSet
from AMGeO.models.covariance import CS10Covariance,Shi20Covariance
from AMGeO.models.conductance import OvationPymeConductance
from AMGeO.observations.supermag import SuperMAG
from AMGeO.observations.superdarn import SuperDARN
from AMGeO.observations.ampere import Ampere
from AMGeO.observations.exceptions import (NoDataAvailableError,
                                            DataWindowBoundaryError)
from AMGeO.downloaders.supermag import download_supermag_data
from AMGeO.downloaders.superdarn import download_superdarn_data
from AMGeO.downloaders.ampere import download_ampere_data
from AMGeO.solvers import ElectricPotentialSolver,MagneticPotentialSolver
from AMGeO.observations.interface import ObservationsCollection,Observations
from AMGeO.datamodel.record import Record,RecordMetadata
from AMGeO.datamodel.interface import RecordCollection
from AMGeO.quadplot import default_quadplot

from AMGeO.caching import CachedDatetimeHemisphereFunction,CachedArrayInputFunction

log = logbook.Logger('AMGeO.driver_default')

def _default_output_directory(asim_date,asim_hemi):
    """Create a directory in the user's home directory
    called amgeo_v2_output, where results and plots will be
    stored. Data and plots for a particular hemisphere and date
    are stored in subdirectories with the format /yyyymmddh where
    h is N for northern hemisphere and S for southern.
    """

    asim_date_str = asim_date.strftime('%Y%m%d')

    outdir = os.path.expanduser("~/amgeo_v2_output")
    outdir = os.path.join(outdir,'%s%s' % (asim_date_str,asim_hemi))

    if not os.path.exists(outdir):
        log.info('Creating directory {}'.format(outdir))
        os.makedirs(outdir)

    log.debug('AMGeO default output directory: {}'.format(outdir))

    return outdir

def _default_start_end_datetimes(centerdt):
    """Create bounding times for data selection from
    center time for labeling amgeo frames/windows
    """
    window_mins = 5

    asim_startdt = centerdt-datetime.timedelta(minutes=window_mins/2.)
    asim_enddt = centerdt+datetime.timedelta(minutes=window_mins/2.)

    return asim_startdt,asim_enddt

def _default_solarwind_datetimes(asim_date):
    """
    Range of times for NASA OMNIweb data for plots. This data
    is used for plots and for input to empirical models.
    """
    year,month,day = asim_date.year,asim_date.month,asim_date.day
    om_startdt = datetime.datetime(year,month,day,0,0,0)\
                                    -datetime.timedelta(days=1)
    om_enddt = datetime.datetime(year,month,day,0,0,0)\
                                    +datetime.timedelta(days=2)
    return om_startdt,om_enddt

@CachedDatetimeHemisphereFunction
def _default_conductance_model():
    """
    Ovation Prime Conductance using 4 Mho and Diffuse aurora only,
    with Brekke and Moen solar conductance turned ON
    """
    log.notice('Loading OvationPyme conductance model...')
    #Ovation Prime Diffuse Aurora
    # + Robinson Formula with Empirical Solar Conductance
    conductance_model = OvationPymeConductance(solar=True,
                                                auroral=True)
    conductance_model.fluxtypes = ['diff']
    conductance_model.background_ped = 4.
    conductance_model.background_hall = 4.
    conductance_model = CachedArrayInputFunction(conductance_model)
    return conductance_model

def _default_background_model(asim_date,asim_hemi):
    """Cousins and Shephard 2010 (CS10) Electric Potential Model
    """
    log.notice('Loading Cousins & Shephard, 2010 (CS10) electric potential model...')
    om_startdt,om_enddt = _default_solarwind_datetimes(asim_date)

    background_model = CS10ElectricPotential(om_startdt,
                                            om_enddt,
                                            asim_hemi)
    return background_model

def _default_shi20_eofs(asim_hemi,kind):
    """The EOF set described in Shi et al. 2020: Modes of (FACs) Variability
    (https://doi.org/10.1029/2019JA027265). Particularly this is the 
    all condition (unsorted) EOF set
    """
    return Shi20EOFSet(asim_hemi,kind=kind)

def _default_mpot_background_model(asim_hemi,kind):
    """Shi 2020 mean magnetic potential derived from Iridium magnetic
    perturbations"""
    eofset = _default_shi20_eofs(asim_hemi,kind)
    def shi20_mean_magnetic_potential_coefficents(asim_date,asim_hemi):
        return eofset.eofset['mean']
    return shi20_mean_magnetic_potential_coefficents

def _default_covariance_model():
    """
    This the background model error covariance for the Cousins and
    Shepard, 2010 (CS10) Electric Potential model.
    This covariance is EOF-based and
    was developed for the SuperDARN Assimilative Mapping (SAM)
    """
    log.notice('Loading CS10 covariance...')
    covariance_model = CS10Covariance()
    return covariance_model

def _default_mpot_covariance_model(asim_hemi,kind):
    """
    Shi2020 EOF-derived error covariance
    """
    eofset = _default_shi20_eofs(asim_hemi,kind)
    return Shi20Covariance(eofset) 

@CachedDatetimeHemisphereFunction
def _default_superdarn(asim_date,asim_hemi):
    """
    SuperDARN observations are by default assimilated as
    electric field observations (line of sight velocity
    crossed with the vertical component of the IGRF field),
    as is done in the SuperDARN Assimilative Mapping (SAM)
    """
    log.notice('Loading SuperDARN data for {}, hemisphere {}...'.format(asim_date,
                                                                        asim_hemi))
    sd = SuperDARN(asim_date,asim_hemi,
                        observation_type='electricfield')
    return sd

@CachedDatetimeHemisphereFunction
def _default_supermag(asim_date):
    """
    All three components (Equatorward,Eastward and Main-Field Aligned)
    of ground magnetic perturbations
    """
    log.notice('Loading SuperMAG data for {}...'.format(asim_date))

    conductance_model = _default_conductance_model()

    #Now we create an object to contain the SuperMAG data
    #This loads the whole day of data from the ASCII file into memory
    sm = SuperMAG(asim_date,conductance_model)

    return sm

@CachedDatetimeHemisphereFunction
def _default_ampere(asim_date):
    """
    Magnetic perturbations in Apex "d" basis
    """
    downsample_high_rate=True
    amp = Ampere(asim_date,downsample_high_rate)

    return amp

def _default_electric_potential_solver(asim_date,asim_hemi):
    """Creates the solver object which produces
    """
    log.notice('Initializing default electric potential solver...')
    background_model = _default_background_model(asim_date,asim_hemi)
    covariance_model = _default_covariance_model()
    conductance_model = _default_conductance_model()

    solver = ElectricPotentialSolver(background_model,
                                    covariance_model,
                                    conductance_model)

    return solver

def _default_magnetic_potential_solver(asim_hemi,mpoteofkind):
    background_model = _default_mpot_background_model(asim_hemi,mpoteofkind)
    covariance_model = _default_mpot_covariance_model(asim_hemi,mpoteofkind)

    solver = MagneticPotentialSolver(background_model,
                                    covariance_model)

    return solver


def _default_observations(asim_date,asim_hemi):
    sd = _default_superdarn(asim_date,asim_hemi)
    sm = _default_supermag(asim_date)
    return sm,sd

class DefaultSolarWind(object):

    def __init__(self,asim_date):
        log.notice('Loading NASA OMNIWeb Solar Wind Data for {}...'.format(asim_date))
        om_startdt,om_enddt = _default_solarwind_datetimes(asim_date)
        self.oi = omni_interval(om_startdt,om_enddt,'5min')
        self.dts = self['Epoch'].flatten().tolist()

    def __getitem__(self,item):
        return self.oi[item]

    def __call__(self,centerdt):
        ind = bisect.bisect_left(self.dts,centerdt)
        dt = self.dts[ind]
        By = self['BY_GSM'][ind]
        Bz = self['BZ_GSM'][ind]
        vsw = self['flow_speed'][ind]
        log.info('Omni for {}\n'.format(centerdt),dt,By,Bz,vsw)
        return By,Bz,vsw

class DefaultResult(object):
    """A container class which stores the data produced by DefaultDriver,
    and can add it to an HDF5 file as a new, self-contained group.

    Properties
    ----------

        dt : datetime.datetime
            The center of the 5-minute window of data used for this result,
            also the time used for any emprical model calls required for this
            result
        hemisphere : str, ['N','S']
            Which polar region (northern or southern) this result corresponds
            to
        name : str
            A string rendering of the datetime and hemisphere properties, which
            is also used as the group name when the result is stored to an
            HDF5 file
        metadata : collections.OrderedDict
            A dictionary of metadata, including the date of the result in
            several formats, the hemisphere, and solar wind conditions
            which is stored as group attributes when the result is stored
            to an HDF5 file
    """
    def __init__(self,prediction_collection,cond_ped,cond_hall,joule_heat,By,Bz,vsw):
        """Prepare the passed data to be stored in and HDF5 file in the
        default format.

        Parameters
        ----------
            prediction_collection : AMGeO.update.predict.PredictionCollection
                A list-like collection of assimilative predictions of electric
                potential, electric field, etc
            cond_ped : numpy.ndarray
                Pedersen conductance [Mho] from OvationPyme
            cond_hall : numpy.ndarray
                Hall conductance [Mho] from OvationPyme
            joule_heat : numpy.ndarray
                Joule heating (calculated as electric_field^2*cond_ped) [mW/m^2]
            By : float
                Interplanetary Magnetic Field (NASA OMNIWeb 5-minute)
                Y component in GSM coordinates [nT]
            Bz : float
                Interplanetary Magnetic Field (NASA OMNIWeb 5-minute)
                Z component in GSM coordinates [nT]
            vsw : float
                Solar wind speed (NASA OMNIWeb 5-minute) [km/s]

        """
        self.dt = prediction_collection.dt
        self.hemisphere = prediction_collection.hemisphere

        self.name = '{}{}'.format(self.dt.strftime('%Y%m%d_%H%M%S'),self.hemisphere)

        self.metadata = self._result_metadata()
        self.metadata['imf_By']=By
        self.metadata['imf_Bz']=Bz
        self.metadata['solar_wind_speed']=vsw

        self._record_collection = RecordCollection()
        self._add_predictions_to_records(prediction_collection)
        self._add_conductance_and_joule_heat_to_records(cond_ped,
                                                        cond_hall,
                                                        joule_heat)
        self._add_integrated_quantities_to_records(joule_heat)

    @staticmethod
    def grid_data_to_record(grid_data,shortname,longname,units):
        record_meta = RecordMetadata(shortname,longname,units)
        record_data = grid.reshape_to_grid(grid_data)
        record = Record(record_data,record_meta)
        return record

    @staticmethod
    def scalar_data_to_record(scalar_data,shortname,longname,units):
        record_meta = RecordMetadata(shortname,longname,units)
        record_data = scalar_data.flatten()
        if len(record_data)>1:
            raise ValueError('Unexpected shape {}'.format(record_data.shape))
        record = Record(record_data,record_meta)
        return record

    def _add_records(self,rec_list):
        for record in rec_list:
            record_name = record['shortname']
            self._record_collection[record_name] = record

    def _result_metadata(self):
        metadata = OrderedDict()
        metadata['hour']=self.dt.hour
        metadata['minute']=self.dt.minute
        metadata['second']=self.dt.second
        metadata['juliandate'] = special_datetime.datetime2jd(self.dt)
        metadata['hemisphere'] = self.hemisphere
        return metadata

    def _add_predictions_to_records(self,prediction_collection):
        for prediction in prediction_collection:
            record_name = prediction.metadata['shortname']
            record_data = grid.reshape_to_grid(prediction.data)
            record_meta = prediction.metadata
            self._record_collection[record_name]=Record(record_data,record_meta)

    def _add_conductance_and_joule_heat_to_records(self,cond_ped,cond_hall,joule_heat):
        recs = []
        recs.append(self.grid_data_to_record(cond_ped,
                                            'cond_ped',
                                            'Ovation Pyme Pedersen Conductance',
                                            'mho'))
        recs.append(self.grid_data_to_record(cond_hall,
                                            'cond_hall',
                                            'Ovation Pyme Hall Conductance',
                                            'mho'))
        recs.append(self.grid_data_to_record(joule_heat,
                                            'joule_heat',
                                            'Joule Heating (E-field^2*Pedersen)',
                                            'mW/m^2'))
        self._add_records(recs)

    def _add_integrated_quantities_to_records(self,joule_heat):
        recs = []
        int_joule_heat = grid.grid_integrate(joule_heat/1000.)/1e9
        recs.append(self.scalar_data_to_record(int_joule_heat,
                                               'int_joule_heat',
                                               'Hemisphere Integrated Joule Heating',
                                               'GW'))
        self._add_records(recs)

    def to_h5(self,h5fn):
        """Store the contents of this DefaultResult object in a
        new group determined by this object's name property. Predictions,
        conductance, and joule heat are stored as HDF5 Datasets. The
        latitudes and longitudes for the results are NOT stored, as all
        results are for the default grid, which is assumed to be stored as
        a top-level Dataset in the HDF5 file.

        Attributes
        ----------

            h5fn : str
                The full file path of the HDF5 file
        """
        with h5py.File(h5fn,'a') as h5f:
            group_name = self.name
            h5group = h5f.create_group(group_name)
            for name,value in self.metadata.items():
                h5group.attrs[name]=value
            self._record_collection._to_h5(h5group)

class DefaultDriver(object):
    """A class which creates the default set of assimilative predictions,
    empirical model results, and solar wind data for a particular
    day and hemisphere

    Attributes
    ----------

        date : datetime.datetime
            The date for which AMGeO results are to be generated.
            Only the year, month and day properties of the datetime are used.
        hemisphere : str
            The single letter hemisphere code N or S denoting whether northern
            or southern hemisphere results are to be generated
        solver : AMGeO.solvers.ElectricPotentialSolver
            The default electric potential solver object
        conductance_model : AMGeO.models.conductance.OvationPymeConductance
            The conductance model which is used in calculation the
            SuperMAG forward operator and in producing the conductance
            results
        sm : AMGeO.observations.supermag.SuperMAG
            The default SuperMAG observations object
        sd : AMGeO.observations.superdarn.SuperDARN
            The default SuperDARN observations object
        obscollection : AMGeO.observations.interface.ObservationCollection
            An object which stores both the SuperDARN and SuperMAG observations
            and is passed into the solver to generate assimilative predictions.
        mpot : bool
            Flag for turning on/off solving magnetic potential
        mpot_solver : AMGeO.solvers.MagneticPotentialSolver
            The default magnetic potential solver (undefined if mpot==False)
        amp : AMGeO.observations.ampere.Ampere
            The default Ampere observations object (undefined if mpot==False)
        mpot_obscollection : AMGeO.observations.interface.ObservationsCollection
            An object which stores the Ampere observations object and
            is passed into the magnetic potential solver to generate
            assimilative predictions (undefined if mpot==False)

    """
    def __init__(self,date,hemisphere,mpot=False,mpoteofkind='all'):
        """Create a class instance which generates default AMGeO results

        Parameters
        ----------

        date : datetime.datetime
            The date for which AMGeO results are to be generated.
            Only the year, month and day properties of the datetime are used.
        hemisphere : str, ['N','S']
            The single letter hemisphere code denoting whether northern
            or southern hemisphere results are to be generated
        mpot : bool, optional
            If True, will also calculate magnetic potential and field
            aligned current using Iridium magnetic perturbations. Default
            False.
        mpoteofkind : str, optional
            Which set of Shi et. al 2020 EOFs to use to calculate prior
            magnetic potential and magnetic potential covariance. Choose
            from 'all'(default), cme, hss, or slw. See references for 
            further information.     

        """
        self.date = date
        self.hemisphere = hemisphere
        self.mpot = mpot

        self.solarwind = DefaultSolarWind(date)
        self.solver = _default_electric_potential_solver(date,hemisphere)
        self.conductance_model = _default_conductance_model()
        self.sm = Observations(_default_supermag(date))
        self.sd = Observations(_default_superdarn(date,hemisphere))
        self.obscollection = ObservationsCollection()
        self.obscollection.append(self.sm)
        self.obscollection.append(self.sd)
        if self.mpot:
            self.mpot_solver = _default_magnetic_potential_solver(hemisphere,mpoteofkind)
            self.amp = Observations(_default_ampere(date))
            self.mpot_obscollection = ObservationsCollection()
            self.mpot_obscollection.append(self.amp)


    def __call__(self,centerdt):
        """Create assimilative predictions, empirical model predictions
        of conductance and solar wind parameters for a particular 5 minute
        window of time.

        Parameters
        ----------

        centerdt : datetime.datetime
            A datetime denoting the center time of the 5 minute window
            for which AMGeO results should be generated. For instance
            the time 03-16-2013 03:02:30 would generate assimilative
            predictions using SuperDARN and SuperMAG data from
            03-16-2013 03:00:00 - 03-16-2013 03:05:00

        Returns
        -------

            prediction_collection : AMGeO.update.predict.PredictionCollection
                A list-like collection of assimilative predictions of electric
                potential, electric field, etc
            cond_ped : numpy.ndarray
                Pedersen conductance [Mho] from OvationPyme
            cond_hall : numpy.ndarray
                Hall conductance [Mho] from OvationPyme
            joule_heat : numpy.ndarray
                Joule heating (calculated as electric_field^2*cond_ped) [mW/m^2]
            By : float
                Interplanetary Magnetic Field (NASA OMNIWeb 5-minute)
                Y component in GSM coordinates [nT]
            Bz : float
                Interplanetary Magnetic Field (NASA OMNIWeb 5-minute)
                Z component in GSM coordinates [nT]
            vsw : float
                Solar wind speed (NASA OMNIWeb 5-minute) [km/s]
        """

        log.notice('Beginning AMGeO run for {}...'.format(centerdt))

        prediction_collection = self.solver(centerdt,
                                            self.hemisphere,
                                            self.obscollection)

        if self.mpot:
            mpot_prediction_collection = self.mpot_solver(centerdt,
                                                          self.hemisphere,
                                                          self.mpot_obscollection)
            prediction_collection.extend(mpot_prediction_collection)

        #Additional data on grid
        cond_ped,cond_hall = self.conductance_model(centerdt,
                                                    self.hemisphere,
                                                    grid.lat_grid,
                                                    grid.lon_grid)

        grid_shape = grid.lat_grid.shape
        E_eastward = prediction_collection['E_ph']['predicted'].reshape(grid_shape)
        E_equatorward = prediction_collection['E_th']['predicted'].reshape(grid_shape)

        joule_heat = (E_eastward**2+E_equatorward**2)*cond_ped
        joule_heat *= 1000. #W->mW

        #Single-value (not arrays) solar wind conditions
        By,Bz,vsw = self.solarwind(centerdt)

        return prediction_collection,cond_ped,cond_hall,joule_heat,By,Bz,vsw

def add_grid_locations_to_h5(h5fn):
    with h5py.File(h5fn,'a') as h5:
        h5.create_dataset('lats',data=grid.lat_grid)
        h5['lats'].attrs['shortname']='lats'
        h5['lats'].attrs['longname']='Modified Magnetic Apex Latitudes'
        h5['lats'].attrs['units']='degrees'
        h5.create_dataset('lons',data=grid.lon_grid)
        h5['lons'].attrs['shortname']='lons'
        h5['lons'].attrs['longname']='Magnetic Local Time in Degrees'
        h5['lons'].attrs['units']='degrees'

if __name__ == '__main__':

    logbook.StreamHandler(sys.stdout).push_application() #Log to terminal

    import argparse

    parser = argparse.ArgumentParser(description="Default AMGeO Processing")

    parser.add_argument("year",
                        help='Year of date to process',type=int,default=None)
    parser.add_argument("month",
                        help='Month of date to process',type=int,default=None)
    parser.add_argument("day",
                        help='Day of date to process',type=int,default=None)
    parser.add_argument("hemisphere",
                        help='Hemisphere (N or S)',type=str,default=None)
    parser.add_argument("--hour",
                        help='Hour',type=int,default=None)
    parser.add_argument("--minute",
                        help='Minute',type=int,default=None)
    parser.add_argument("--second",
                        help='Second',type=int,default=None)
    parser.add_argument("--output_dir",
                        help=('Directory for plots and hdf5 files'
                            +' (default: ~/amgeo_v2_output)'),
                        type=str,default=None)
    parser.add_argument("--nowrite",
                        help='Do not try to write results to HDF5 file',
                        action='store_true',default=False)
    parser.add_argument("--mpot",
                        help=('Turn on magnetic potential solver (uses'
                              +' AMPERE (Iridium) data)'),
                        action='store_true',default=False)
    parser.add_argument("--mpoteofkind",
                        help=('Which Shi20 EOF set (all,cme,hss,slw)'
                              +' will be used in magnetic potential solver'
                              +' default: all'),
                        type=str,default='all')
    args = parser.parse_args()
    write_hdf5 = not args.nowrite

    year,month,day = args.year,args.month,args.day
    hour,minute,second = args.hour,args.minute,args.second
    hemisphere = args.hemisphere
    mpot = args.mpot
    mpoteofkind = args.mpoteofkind

    datedt = datetime.datetime(year,month,day)

    if args.output_dir is None:
        outdir = _default_output_directory(datedt,hemisphere)
    else:
        outdir = args.output_dir

    driver = DefaultDriver(datedt,hemisphere,mpot=mpot,mpoteofkind=args.mpoteofkind)
    h5fn = os.path.join(outdir,'amgeo_v2_{}{:02d}{:02d}{}.h5'.format(year,
                                                                    month,
                                                                    day,
                                                                    hemisphere))

    if write_hdf5:
        if os.path.exists(h5fn):
            raise RuntimeError('Output file {} already exists'.format(h5fn))

        add_grid_locations_to_h5(h5fn)
        
    if hour is not None and minute is not None and second is not None:

        #Run one time only
        single_datetime = datetime.datetime(year,month,day,hour,minute,second)
        center_datetimes = [single_datetime]

    else:

        startdt = datetime.datetime(year,month,day,0,2,30)
        delta_dt = datetime.timedelta(minutes=5)
        center_datetimes = [startdt + datetime.timedelta(minutes=i*5) for i in range(1339)]

    for centerdt in center_datetimes:

        driver_outs = driver(centerdt)

        result = DefaultResult(*driver_outs)
        if write_hdf5:
            result.to_h5(os.path.join(outdir,h5fn))

        default_quadplot(*driver_outs,
                            supermag_observations=driver.sm,
                            superdarn_observations=driver.sd,
                            ampere_observations=None if not driver.mpot else driver.amp,
                            plotdir=outdir)
