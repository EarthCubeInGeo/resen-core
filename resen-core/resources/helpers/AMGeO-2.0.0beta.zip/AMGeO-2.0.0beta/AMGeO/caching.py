#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration

import datetime, os
from collections import OrderedDict
import numpy as np

class CachedDatetimeHemisphereFunction(object):
    """Cache the output of a function which takes either
        1. No arguments or keyword arguments
        1. Only a datetime as an argument (no keyword arguments)
        2. Only datetime and hemisphere code ('N' or 'S') (no keyword arguments)
        """

    def __init__(self,func):
        self.func = func
        self.funcname = self.func.__name__
        self.cache = OrderedDict()
        self._cache_max_size=10

    def _check_is_datetime(self,dt):
        if not isinstance(dt,datetime.datetime):
            raise ValueError(('First {} argument'.format(self.funcname)
                             +'must be a datetime.datetime'))

    def _check_is_hemisphere(self,hemisphere):
        if hemisphere not in ['N','S']:
            raise ValueError(('Second {} argument'.format(self.funcname)
                             +'must be N or S'))

    def _check_wrapper_inputs(self,*args,**kwargs):
        if len(kwargs.keys())>0:
            raise ValueError(('This decorator cannot be used with functions'
                             +' which take keyword arguments'))
        if len(args)==0:
            return None
        elif len(args)==1:
            dt = args[0]
            self._check_is_datetime(dt)
            return (dt,)
        elif len(args)==2:
            dt,hemisphere = args[0],args[1]
            self._check_is_datetime(dt)
            self._check_is_hemisphere(hemisphere)
            return dt,hemisphere
        else:
            raise ValueError(('This decorator can only be used ')
                             +'on functions which take 0-2 arguments '
                             +' and no keyword arguments'
                             +'recieved: args:{} kwargs:{}'.format(args,kwargs))

    def __call__(self,*args,**kwargs):
        checked_args = self._check_wrapper_inputs(*args,**kwargs)

        #Handle possiblity that we are caching a function with no arguments
        #in this case _check_wrapper_inputs returns None
        func_args = () if checked_args is None else checked_args
        cache_key = None if checked_args is None else checked_args

        if cache_key in self.cache:
            pass
            # print('{} read cache[{}]={}'.format(self.funcname,
            #                                     func_args,
            #                                     self.cache[cache_key]))
        else:
            if len(self.cache.keys())>=self._cache_max_size:
                oldest_cache_key = [key for key in self.cache.keys()][0]
                # print('{} deleted cache[{}]={}'.format(self.funcname,
                #                                 oldest_cache_key,
                #                                 self.cache[oldest_cache_key]))
                del(self.cache[oldest_cache_key])

            self.cache[cache_key] = self.func(*func_args)
            # print('{} added cache[{}]={}'.format(self.funcname,
            #                                     func_args,
            #                                     self.cache[cache_key]))
        return self.cache[checked_args]


class CachedArrayInputFunction(object):
    """Cache the outputs of a function which accepts
    positional inputs which include numpy arrays.
    """
    def __init__(self,func):
        self.func = func
        self.funcname = self.func.__name__ if hasattr(self.func,'__name__') else str(self.func)
        self.cache = OrderedDict()
        self._cache_max_size = 10

    def _check_wrapper_inputs(self,*args,**kwargs):
        if len(kwargs.keys())>0:
            raise ValueError(('This decorator cannot be used with'
                             +' keyword arguments'))

        if len(args)==0:
            raise ValueError(('This decorator cannot be used with functions'
                              +' which take no arguments'))

        n_arrays = sum([1 if isinstance(arg,np.ndarray) else 0 for arg in args])
        if n_arrays == 0:
            raise ValueError(('This decorator should only be used'
                              +' on functions for which at least one'
                              +' input is an np.ndarray'))

    def _cache_key_from_inputs(self,*args):
        cache_key_parts = []
        for arg in args:
            if not isinstance(arg,np.ndarray):
                cache_key_parts.append(str(arg))
            else:
                arr = arg
                cache_key_parts.append(str(hash(arr.tostring())))
        return '_'.join(cache_key_parts)

    def __call__(self,*args,**kwargs):
        self._check_wrapper_inputs(*args,**kwargs)
        cache_key = self._cache_key_from_inputs(*args)

        if cache_key in self.cache:
            pass
            # print('{} read cache[{}]'.format(self.funcname,
            #                                     cache_key))
        else:
            if len(self.cache.keys())>=self._cache_max_size:
                oldest_cache_key = [key for key in self.cache.keys()][0]
                #print('{} deleted cache[{}]'.format(self.funcname,
                #                                oldest_cache_key))
                del(self.cache[oldest_cache_key])

            self.cache[cache_key] = self.func(*args)
            #print('{} added cache[{}]={}'.format(self.funcname,
            #                                    cache_key,
            #                                    self.cache[cache_key]))
        return self.cache[cache_key]

