import random,datetime,os,pdb
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns

from AMGeO.observations import superdarn
from AMGeO.observations.interface import ObservationsCollection
from AMGeO.observations.interface import DynamicallyMaskedObservations
from AMGeO.update.interface import Validator
from driver_default import _default_electric_potential_solver,_default_supermag

def _validation_superdarn(asim_date,asim_hemi):
    """
    SuperDARN observations are by default assimilated as
    electric field observations
    (line of sight velocity crossed with the vertical component of
    the IGRF field), as is done in the SuperDARN Assimilative Mapping (SAM)
    for calculating residuals, as will be done with this
    instance, we instead use the operators appropriate
    for ion drifts directly, so it is easier to interpret the results
    """
    sd = superdarn.SuperDARN(asim_date,asim_hemi,
                                observation_type='iondriftvelocity')
    return sd

class FoldMask(object):
    def __init__(self,fold_number,k,train_or_test):
        """A class which, when called produces an index array which
        represent the fold_number-th subsample (fold)
        of a k-fold cross validation.
        By seeding the random number generator using a seed based on the
        inputs to __call__, the index array is pseudorandom, but also
        deterministic (so calling again with the same __call__
        args will always produce the same index array)
        """
        if fold_number < 1 or fold_number > k:
            raise ValueError('Fold number must be between 1 and {}'.format(k))

        if train_or_test not in ['train','test']:
            raise ValueError(('Invalid value {}'.format(train_or_test),
                              +'valid values are train or test'))

        self.fold_number = fold_number
        self.k = k
        self.train_or_test = train_or_test

    def _check_flat(self,*arrays):
        if any(len(arr.shape)>1 for arr in arrays):
            raise ValueError('Only flat arrays allowed')

    def _get_inds_in_fold(self,npts,random_seed):
        indices = np.arange(npts).tolist()
        n_pts = len(indices)
        n_per_fold = int(n_pts/self.k)
        i_fold_start = (self.fold_number-1)*n_per_fold
        i_fold_end = self.fold_number*n_per_fold
        random.seed(a=random_seed)
        randomized_indices = [ind for ind in indices] #copy
        random.shuffle(randomized_indices)
        fold_indices=randomized_indices[i_fold_start:i_fold_end]
        print('Seed:{}, indices[0]: {}'.format(random_seed,
                                                randomized_indices[0]))
        return fold_indices

    def __call__(self,dt,hemisphere,lats,lons):
        self._check_flat(lats,lons)
        npts = len(lats)
        seed = str(dt)+str(hemisphere)+str(lats[0])+str(lons[-1])
        fold_inds = self._get_inds_in_fold(npts,seed)
        if self.train_or_test=='train':
            # If this is a train mask generator, we want all data except the
            # data selected for this fold
            mask = np.ones((npts,),dtype=bool)
            mask[fold_inds]=False
        elif self.train_or_test=='test':
            # If this is a test mask generator, we want the validation data
            # for this fold
            mask = np.zeros((npts,),dtype=bool)
            mask[fold_inds]=True
        return mask

class KFoldCrossValidation(object):

    def __init__(self,solver,observations_list,k):
        self.k = k
        outs = self._get_validators_and_observations_collections(solver,
                                                                 observations_list)
        self.validators,self.observations_collections = outs


    def _generate_folds_observations_wrappers(self,observations,component_name=None):
        train_obs = []
        test_obs = []
        for i_k in range(self.k):
            fold_number = i_k+1 #Fold numbers are 1-based
            train_masker = FoldMask(fold_number,self.k,'train')
            train_obs.append(DynamicallyMaskedObservations(observations,
                                                           train_masker,
                                                           component_name=component_name))

            test_masker = FoldMask(fold_number,self.k,'test')
            test_obs.append(DynamicallyMaskedObservations(observations,
                                                           test_masker,
                                                           component_name=component_name))
        return train_obs,test_obs

    @staticmethod
    def _iter_observations_components(observations_list):
        for observations in observations_list:
            if not hasattr(observations,'components'):
                components = None
            else:
                components = observations.components

            if not isinstance(components,list):
                components = [components]

            for component in components:
                yield observations,component

    def _get_validators_and_observations_collections(self,solver,observations_list):

        validators = [Validator(solver) for i_fold in range(self.k)]
        observations_collections = [ObservationsCollection() for i_fold in range(self.k)]

        for observations,component in self._iter_observations_components(observations_list):
            outs = self._generate_folds_observations_wrappers(observations,component_name=component)
            train_observations,test_observations = outs
            for i_fold in range(self.k):
                observations_collections[i_fold].append(train_observations[i_fold])
                validators[i_fold].append(test_observations[i_fold])

        return validators,observations_collections

    def __call__(self,dt,hemisphere):
        residual_collections = []
        for i_fold in range(self.k):
            validator_args = (dt,hemisphere,self.observations_collections[i_fold])
            residual_collection = self.validators[i_fold](*validator_args)
            residual_collections.append(residual_collection)
        return residual_collections

def make_residuals_dataframe(residual_collections,obs_shortname,component_shortname):
    residual_name = obs_shortname+'_'+component_shortname+'_'+'res'
    values = []
    flags = []
    foldnumbers = []
    for i_fold,residual_collection in enumerate(residual_collections):
        fold_pri_pred = residual_collection[residual_name]['prior_predicted'].flatten()
        fold_pred = residual_collection[residual_name]['predicted'].flatten()
        fold_obs = residual_collection[residual_name]['observed'].flatten()

        values.append(fold_obs)
        flags.append(np.ones_like(fold_pred,dtype=int)*0)
        foldnumbers.append(np.ones_like(fold_pred,dtype=int)*(i_fold+1))

        values.append(fold_pri_pred)
        flags.append(np.ones_like(fold_pri_pred,dtype=int)*1)
        foldnumbers.append(np.ones_like(fold_pri_pred,dtype=int)*(i_fold+1))

        values.append(fold_pred)
        flags.append(np.ones_like(fold_pred,dtype=int)*2)
        foldnumbers.append(np.ones_like(fold_pred,dtype=int)*(i_fold+1))

    df = pd.DataFrame({'value':np.concatenate(values),
                       'flag':np.concatenate(flags),
                       'foldnumber':np.concatenate(foldnumbers)})

    df['obs_pred']=df['flag'].map({0:'observed',1:'CS10',2:'AMGeO'})
    return df

def folds_boxplot(df):
    ymin,ymax = np.nanpercentile(df['value'],3),np.nanpercentile(df['value'],97)

    f = plt.figure(figsize=(8,8))
    ax = f.add_subplot(111)
    n_obs = len(df['value'].values)/2
    n_per_fold = np.count_nonzero(df['foldnumber']==1)
    ax.set_title('{} observations / {} test observervations per fold'.format(n_obs,n_per_fold))
    sns.boxplot(x='foldnumber',y='value',hue='obs_pred',data=df,ax=ax)
    ax.set_ylim([ymin,ymax])
    return f

def overall_histogram(df):

    f=plt.figure(figsize=(8,12))
    axs = [f.add_subplot(3,1,iax) for iax in [1,2,3]]
    obs_preds = ['observed','CS10','AMGeO']

    xmin,xmax = np.nanpercentile(df['value'],3),np.nanpercentile(df['value'],97)

    for ax,obs_pred in zip(axs,obs_preds):
        data = df['value'][(df['obs_pred']==obs_pred)]
        sns.distplot(data,kde=False,
                        bins=np.linspace(xmin,xmax,30),
                        label=obs_pred,
                        ax=ax)
        ax.set_xlim([xmin,xmax])
        ax.legend()
    return f

if __name__ == '__main__':
    asim_date = datetime.datetime(2015,3,16)
    asim_hemi = 'N'

    sd = _validation_superdarn(asim_date,asim_hemi)
    sm = _default_supermag(asim_date)

    solver = _default_electric_potential_solver(asim_date,asim_hemi)
    k=10
    k_fold_cross_validation = KFoldCrossValidation(solver.solver,[sm],k)

    centerdt = datetime.datetime(2015,3,16,3,2,30)
    residual_collections = k_fold_cross_validation(centerdt,asim_hemi)

    obs_shortname = 'gdB'
    for component_shortname in ['th','ph','B']:
        df = make_residuals_dataframe(residual_collections,
                                        obs_shortname,component_shortname)
        f = overall_histogram(df)
        f.suptitle('{}-fold Cross Validation\n {} {} {}'.format(k,obs_shortname,
                                                                component_shortname,
                                                                centerdt.strftime('%H:%M')))
        f.savefig(os.path.expanduser('~/{}_{}_k{}_hist_{}_{}.png'.format(obs_shortname,
                                                                      component_shortname,
                                                                      k,
                                                                      centerdt,
                                                                      asim_hemi)))

        f = folds_boxplot(df)
        f.suptitle('{}-fold Cross Validation\n {} {} {}'.format(k,obs_shortname,
                                                                component_shortname,
                                                                centerdt.strftime('%H:%M')))
        f.savefig(os.path.expanduser('~/{}_{}_k{}_folds_{}_{}.png'.format(obs_shortname,
                                                                      component_shortname,
                                                                      k,
                                                                      centerdt,
                                                                      asim_hemi)))



