#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
from collections import OrderedDict
import logbook
from AMGeO.update.kalman import kalman_update
from AMGeO.update.assimilate import Mapping,Prediction,Residual

log = logbook.Logger('AMGeO.update.predict')

class PredictionCollection(object):
    """dict-like group of update.assimilate.Prediction instances
    """
    def __init__(self,dt,hemisphere):
        self.dt = dt
        self.hemisphere = hemisphere
        self._predictions = []
        self._shortnames = []

    def append(self,prediction):
        self._predictions.append(prediction)
        self._shortnames.append(prediction.metadata['shortname'])

    def extend(self,prediction_collection):
        for prediction in prediction_collection._predictions:
            self.append(prediction)

    def __iter__(self):
        for prediction in self._predictions:
            yield prediction

    def items(self):
        for shortname in self._shortnames:
            yield shortname,self[shortname]

    def __getitem__(self,slice_or_index_or_shortname):
        if slice_or_index_or_shortname in self._shortnames:
            shortname = slice_or_index_or_shortname
            i_prediction = self._shortnames.index(shortname)
            return self._predictions[i_prediction]
        else:
            slice_or_index = slice_or_index_or_shortname
            return self._predictions[slice_or_index]

class ResidualCollection(object):
    """dict-like group of update.assimilate.Residual instances
    """
    def __init__(self,dt,hemisphere):
        self.dt = dt
        self.hemisphere = hemisphere
        self._residuals = []
        self._shortnames = []

    def append_from_prediction(self,prediction,observations):
        self.append(Residual(prediction,observations))

    def append(self,residual):
        self._residuals.append(residual)
        self._shortnames.append(residual.metadata['shortname'])

    def __iter__(self):
        for residual in self._residuals:
            yield residual

    def items(self):
        for shortname in self._shortnames:
            yield shortname,self[shortname]

    def __getitem__(self,slice_or_index_or_shortname):
        if slice_or_index_or_shortname in self._shortnames:
            shortname = slice_or_index_or_shortname
            i_residual = self._shortnames.index(shortname)
            return self._residuals[i_residual]
        else:
            slice_or_index = slice_or_index_or_shortname
            return self._residuals[slice_or_index]

class MappingCollection(object):
    """dict-like group of update.assimilate.Mapping instances, which when __call__'ed
    performs the Kalman update
    """
    def __init__(self,background_model,covariance_model):
        """
        Parameters
        ----------
        fundamental_quantity : update.assimilate.FundamentalQuantity
            The quantity predicted by the background model

        """
        self.background_model = background_model
        self.covariance_model = covariance_model
        self._mappings = []

    @classmethod
    def from_existing(cls,mapping_collection):
        """Generate a new MappingCollection with the same background model
        and covariance model as the input instance
        """
        return cls(mapping_collection.background_model,
                    mapping_collection.covariance_model)

    def append_from_target(self,prediction_target):
        """prediction_target must be either an OperatorOnGrid or an
        OperatorFromObservations"""
        mapping = Mapping(self.background_model,
                            self.covariance_model,
                            prediction_target)

        self.append(mapping)

    def append(self,mapping):
        if not isinstance(mapping,Mapping):
            raise TypeError('{} is not a Mapping'.format(mapping))

        self._mappings.append( mapping )

    def __getitem__(self,slice_or_index):
        return self._mappings[slice_or_index]

    def __iter__(self):
        for mapping in self._mappings:
            yield mapping

    def __call__(self,dt,hemisphere,observation_collection):
        mapping_call_args = (dt,hemisphere,observation_collection)

        kalman_ingredients = []
        kalman_results_metadata = []
        for mapping in self:
            log.debug(mapping_call_args)
            ingredients,result_metadata = mapping(*mapping_call_args)
            kalman_ingredients.append(ingredients)
            kalman_results_metadata.append(result_metadata)

        #Actually perform the update (this could be distributed across workers)
        kalman_results = [kalman_update(ingredients) for ingredients in kalman_ingredients]

        predictions = PredictionCollection(dt,hemisphere)
        for result,result_meta in zip(kalman_results,kalman_results_metadata):
            predictions.append(Prediction(dt,hemisphere,result,result_meta))

        return predictions

