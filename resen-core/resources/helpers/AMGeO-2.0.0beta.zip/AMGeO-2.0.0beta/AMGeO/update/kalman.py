#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
import numpy as np
import scipy,os,datetime
import matplotlib as mpl
from AMGeO.update.localize import GaspariCohnCorrelationPolar

class KalmanUpdateIngredients(object):
    """Stores inputs for the Kalman update step of the
    assimilative mapping.

    Class instances will be passed to
    the update function outside of this class (update is not a method)
    This allows paralell update calculations using multiprocessing pool.map

    Note to future developers:
    Instances of this class must be pickleable (so that they can be used with
    pool.map)

    Nomenclature:
    x - the assimilation variable (the quantity described by the prior state
        and the result predicted by the kalman updates
        (example: the quantity represented by x could be electric potential)
    y - the observations (the new information that will used in Bayes' rule
        by the Kalman update to inform the posterior state estimate)
        (example: the quantity represented by y could be ion drift velocity
        observed by coherent scatter radar)
    H - the matrix which is the (linearized) transformation from the
        the state quantity described by x into the observations quantity
        described by y (example: if x represents electric potential and
        y represents ion drift velocity (v), then H would represent the linearized
        form of the electrodynamic relationship:
            phi = -grad(E), where E = -v x B, and B is the earth's magnetic field

    Attributes
    ----------
    x_prior - the initial state of the assimilation variable
    Cb - the background error covariance (prior uncertainty / uncertainty about
            the inital state)

    y_lats - the Kalman inputs' (observations) Apex latitudes
    y_lons - the Kalman inputs' (observations) Magnetic Local Times in degrees
    y - the inputs (observations) vector
            dimension = n_observations x 1
    H_y -  The H matrix (described above) calculated at the locations
            in y_lats/y_lons
            shape = len(y_lats) x n_basis_functions
    Cr - The (probably) diagonal representativeness / observation
            error covariance matrix (i.e. Cr[i,j] it is
            the covariance of the i-th observation
            with the j-th observation)
            shape = n_observations x 1
    out_lats - the Kalman update outputs' Apex latitudes (usually the location grid,
                but could be observation locations if update is, for instance,
                predicting observations not used in the assimilative mapping
                for cross validation)
    out_lons - the Kalman update outputs' magnetic local time in degrees
    H_out - the H matrix (described above) calculation for the locations
            of (out_lats/out_lons)
    """
    def __init__(self,x_prior,Cb,y_lats,y_lons,y,Cr,H_y,out_lats,out_lons,H_out):
        self.x_prior = x_prior
        self.Cb = Cb

        self.y_lats = y_lats
        self.y_lons = y_lons
        self.y = y
        self.Cr = Cr
        self.H_y = H_y

        self.out_lats = out_lats
        self.out_lons = out_lons
        self.H_out = H_out

        #Default localization correlation distance in meters
        self._default_c = 6.481e6*np.pi/10 #18-36 deg

        #For now this is locked this way
        self.c = self._default_c

    def observation_space_ingredients(self):
        """Return the inputs that are associated with the observations
        All of these have the number of observations as the first dimension
        """
        return self.y_lats,self.y_lons,self.y,self.Cr,self.H_y

    def basis_space_ingredients(self):
        """Return the inputs that are only related to basis functions.
        All of these have first dimension size equal to the number
        of basis functions used (244 by default)
        """
        return self.x_prior,self.Cb

    def output_space_ingredients(self):
        """Return the inputs that are related to the output grid or vector
        or locations, i.e. the locations at which you want to evaluate
        the result of the update
        """
        return self.out_lats,self.out_lons,self.H_out

class KalmanUpdateResults(object):
    """
    Stores the results of a Kalman update and the ingredients (inputs) used
    to perform the update

    Each KalmanUpdateResults instance is always paired with a
    KalmanUpdateIngredients instance

    All results arrays have locations along the first dimension,
    the locations are those in the out_lats/out_lons variables from the
    KalmanUpdateIngredients instance which created this KalmanUpdateResults
    instance

    Attributes
    ----------

    lats - np.ndarray, shape (n_locations,)
        Apex latitudes of the results
    lons - np.ndarray, shape (n_locations,)
        Magnetic local time in degrees of the results
    prior_predicted - np.ndarray (n_locations,)
        Predictions for the state variable at the locations of lats/lons,
        BEFORE the Kalman update
    prior_error_covariance - np.ndarray (n_locations,n_locations)
        Uncertainty (covariance) of the prior predicitons, more specifically
        the background / prior covariance matrix Cb for the state variable /
        the quantity represented by x
    predicted - np.ndarary (n_locations,)
        Predictions of the state variable at the locations of lats/lons,
        AFTER the Kalman update
    analysis_error_covariance - np.ndarray (n_locations,n_locations)
        Uncertainty (covariance) of the predicitons, more specifically
        the result of updating the background model error covariance
        via the Kalman update
    """
    def __init__(self,lats,lons,
                        predicted,analysis_error_covariance,
                        prior_predicted,prior_error_covariance):
        self.lats = lats
        self.lons = lons
        self.predicted = predicted
        self.analysis_error_covariance = analysis_error_covariance
        self.prior_predicted = prior_predicted
        self.prior_error_covariance = prior_error_covariance

def calculate_correlation_matrices(lats1,lons1,lats2,lons2,c):
    """Calculate the Gaspari-Cohn correlation matrices between all possible
    possible combinations of 2 sets of locations in polar coorindates

    Inputs
    ------

    lats1 - np.ndarray - shape (n1,)
        Latitudes of location set 1
    lons1 - np.ndarray - shape (n1,)
        Longitudes of location set 1
    lats2 - np.ndarray - shape (n2,)
        Latitudes of location set 2
    lons2 - np.ndarray - shape (n2,)
        Longitudes of location set 2
    c - float
        The correlation distance in meters
    """
    thetas1 = np.radians(90.-lats1).flatten()
    phis1 = np.radians(lons1).flatten()

    thetas2 = np.radians(90.-lats2).flatten()
    phis2 = np.radians(lons2).flatten()

    COR11 = GaspariCohnCorrelationPolar(thetas1,phis1,
                                        thetas1,phis1,
                                        c)

    COR22 = GaspariCohnCorrelationPolar(thetas2,phis2,
                                        thetas2,phis2,
                                        c)

    COR12 = GaspariCohnCorrelationPolar(thetas1,phis1,
                                        thetas2,phis2,
                                        c)

    #TODO is COR12 == COR21.T?
    COR21 = GaspariCohnCorrelationPolar(thetas2,phis2,
                                        thetas1,phis1,
                                        c)
    return COR11,COR22,COR12,COR21

def kalman_update(update_ingredients):
    """Perform the Kalman update step, i.e. do the optimal interpolation

    Parameters
    ----------
    localize : bool, optional
        Apply Gaspari-Cohn localization to covariance matrices?
    gridH : None or np.ndarray, optional
        Forward operator H for electrodynamic quanitity of interest
        (potential,E-field,velocity) (for desired result locations)
        None to use class default (self.pot)
    c : None or float, optional
        Localization tapering distance (in km)
        None to use class default (R_e+h_r)*np.pi/10
        Where R_e is earth radius and h_r is 110 km
    lat_grid : None, optional
        Latitudes of desired result locations
        If None uses default AMGeO grid
    lon_grid : None, optional
        Longitudes of desired result locations
        If None uses default AMGeO grid

    Returns
    -------
    x_posterior : np.ndarray
        Coefficients
    predicted : np.ndarray
        Predicted values of electrodynamic quantity
        described by gridH
    analysis_error_covariance : np.ndarray
        Predicted uncertainty (covariance) of results
    prior_predicted : np.ndarray
        Background model prediction of values of electrodynamic
        quantity described by gridH
    prior_model_error_covariance : np.ndarray
        Uncertainty (covariance) of background model prediction
        of quantity described by gridH

    """
    # Observation space update ingedients
    # (length (1D) or number of rows (2D) == number of observations == len(y) )
    y_lats,y_lons,y,Cr,H_y = update_ingredients.observation_space_ingredients()

    # Basis function space update ingredients
    # (length (1D) or number of rows (2D) == number of basis functions == 244)
    x_prior,Cb = update_ingredients.basis_space_ingredients()

    # Output space update ingredients
    # (length (1D) or number of rows (2D) == number of output locations )
    out_lats,out_lons,H_out = update_ingredients.output_space_ingredients()

    # Prior state (x_prior) is weight of each basis function
    # from regression of state variable background model
    # prediction against basis function values for state variable

    if len(y) == 0:
        #TODO raise warning
        #No Observations, Return background model predictions
        print("WARNING: Unable to perform OI because too few observations!"
                +"Return background predictions.")
        return_background_prediciton = True
    elif H_out.shape[0] == 0:
        #TODO raise warning
        print("WARNING: Unable to perform OI because no output locations")
        return_background_prediciton = True
    else:
        return_background_prediciton = False


    if not return_background_prediciton:

        CORs = calculate_correlation_matrices(y_lats,y_lons,
                                                out_lats,out_lons,
                                                update_ingredients.c)

        COR_y_y,COR_out_out,COR_y_out,COR_out_y = CORs

        #localized H*COV*H' (what is this 'physically')
        Hy_Cb_HyT  = COR_y_y*np.dot(H_y,np.dot(Cb,H_y.T))

        #Calculate the denominator for the gain matrix
        innerK = np.linalg.inv(Hy_Cb_HyT + Cr)

        #localized grid_pot*COV*H'
        Hout_Cb_HyT = COR_out_y*np.dot(np.dot(H_out,Cb),H_y.T)

        #For predicting observations
        #Hy_Cb_Hout = COR_out_y.T*np.dot(np.dot(Hy,Cb),Hout.T)
        #TODO Verify COR_out_y == COR_y_out.T
        Hy_Cb_HoutT = COR_y_out*np.dot(np.dot(H_y,Cb),H_out.T)

        #Finish computing gain (numerator Cb*H.T is localized grid-obs,
        #denominator H*Cb*H.T is localized obs-obs)
        K = np.dot(Hout_Cb_HyT,innerK)

        #localized grid_pot*COV*grid_pot'
        Hout_Cb_Hout = COR_out_out*np.dot(np.dot(H_out,Cb),H_out.T)

        #Get prior predicitons at output and observation locations
        prior_predicted = np.dot(H_out,x_prior)

        # print('H_out',H_out.shape)
        # print('prior_predicted',prior_predicted.shape)

        y_prior = np.dot(H_y,x_prior)

        #Kalman update
        predicted = (prior_predicted + np.dot(K ,(y.reshape(-1,1)-y_prior)))
        # print('K',K.shape)
        # print('y',y.shape)
        # print('y_prior',y_prior.shape)
        # print('y-y_prior',(y-y_prior).shape)
        # print('predicted',predicted.shape)


        #Localized Analysis Error
        analysis_error_covariance = (Hout_Cb_Hout
                                    - np.dot(K,Hout_Cb_HyT.T))

        #Get the background model predictions and errors
        # TODO should this be localized or not?? It was before !?!?
        prior_model_error_covariance = Hout_Cb_Hout #localized
        #prior_model_error_covariance = np.dot(np.dot(H_out,Cb),H_out.T)

    else:

        predicted = np.dot(H_out,x_prior)
        # TODO should this be localized or not??
        analysis_error_covariance = np.dot(H_out,np.dot(Cb,H_out.T))
        prior_predicted=predicted
        prior_model_error_covariance=analysis_error_covariance

    return KalmanUpdateResults(out_lats,out_lons,
                                predicted,analysis_error_covariance,
                                prior_predicted,prior_model_error_covariance)


