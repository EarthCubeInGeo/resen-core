
# The Assimilative Mapping of Geospace Observations
[AMGeO Website](https://amgeo.colorado.edu)  
[AMGeO Whitepaper](https://doi.org/10.5281/zenodo.3564913)  
amgeo@colorado.edu  

## How to Cite

Please cite the whitepaper above

## Python Version and Operating System

We have tested the following configurations so far: 
* Ubuntu 18.04 Linux running Python 2.7 (Anaconda)
* Ubuntu 18.04 Linux running Python 3.7 (Anaconda)
* Mac OSX Mojave running Python 3.7 (Anaconda)

## Accessing the Data Service

To run AMGeO you will need to register at https://amgeo.colorado.edu and get an API
key. Your API key links your local installation to your account on our website, and allows you
to download data through our web service.

	The AMGeO data service keeps a log of which API keys are requesting data and how often.
	We will report statistics based on this information to funding agencies 
	(e.g. National Science Foundation). Such reports will never contain
	personally identifiable information (e.g. usernames, email addresses) of AMGeO users.
	See the AMGeO license and privacy policy for further information.

After you have registered, get your API key by:

1. Log in at https://amgeo.colorado.edu/login
2. Go to the account page https://amgeo.colorado.edu/account or click your username in the top right corner of the page
3. Click the API key button

You will need to copy your API key from the website and paste it into your terminal when you run the configuration script (see below).

## Installation

1. Make sure numpy is installed

```{sh}
pip install numpy
```

2. Clone the AMGeO Github repository

```{sh}
git clone https://github.com/amgeo-collaboration/AMGeO.git
``` 

3. Install the latest versions of the AMGeO dependancies
>:warning: You must have a fortran compiler (e.g. gfortran) installed for this step

```{sh}
cd AMGeO
pip install -r requirements.txt
```

4. Install AMGeO itself in develop mode

```{sh}
python setup.py develop
````

## Configuration
	
Ensure you have your API key (above)

You will also need a SuperMAG username (http://supermag.jhuapl.edu/),

Using your terminal navigate to the directory where you cloned 
the AMGeO Git repository and run the configuration script:

```{sh}
python configure.py
```

The script will ask you for:

* Your AMGeO API key
* Your SuperMAG username
* Your AMPERE username

## Run

To make a basic AMGeO plot do the following:

```{sh}
python driver_default.py 2015 3 17 N --hour 3 --minute 2 --second 30
```

A plot of the AMGeO result for 3-17-2015 03:00 - 03:05 will be added to your
home directory in a folder called amgeo_v2_output.

To run an entire day and save the results into an HDF5 file:
```{sh}
python driver_default.py 2015 3 17 N
```
To run using Iridium data to calculate assimilative predictions of field-aligned currents:
```
python driver_default.py 2015 3 17 N --mpot --mpoteofkind cme
```
>:warning: Field-aligned current solver is a work-in-progress. Use `--mpoteofkind cme` if running a storm, `--mpoteofkind all` otherwise.

To see all available commands
```
python driver_default.py --help
```

See data inventory pages for [SuperMAG](http://supermag.jhuapl.edu) and [SuperDARN](vt.superdarn.org/tiki-index.php?page=Data+Inventory) and [Ampere](http://ampere.jhuapl.edu) for when data is available.
	
