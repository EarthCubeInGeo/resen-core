#Copyright 2018, The Regents of the University of Colorado, a body corporate
#Created by the CU Boulder AMGeO Collaboration
from AMGeO.files.config import save_config,load_config,config_file
import os

def input23(prompt):
	try:
		return raw_input(prompt)
	except NameError:
		#Python 3
		return input(prompt)

config = load_config() if os.path.exists(config_file) else {}

config['amgeo']={}
config['amgeo']['api_key']=input23("Enter your AMGeO API key: ")

config['supermag']={}
config['supermag']['username']=input23("Enter your SuperMAG username: ")

config['ampere']={}
config['ampere']['username']=input23("Enter your Ampere username: ")

# config['superdarn']={}
# config['superdarn']['username']=input23("Enter your SuperDARN username: ")
# config['superdarn']['password']=input23("Enter your SuperDARN password: ")

#Currently, there is no need to authenticate with the superdarn
#data service
config['superdarn']={}
config['superdarn']['username']='amgeouser'
config['superdarn']['password']='none'

save_config(config)
